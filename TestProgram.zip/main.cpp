﻿#include"cloudgamefix.hpp"
#include"cgFix.h"

int main(int argc,LPCSTR* argv)
{
	/*一个简单的应用程序示例*/
	IUnknown * ptr = cgZero::Interface::cgFix::CreateInstance(); //声明指针并创建cgFix接口的实例
	cgZero::Interface::cgFix* cf = nullptr; //声明空指针对象
	HRESULT hr = ptr->QueryInterface(cgZero::Interface::sigmaInterface::guid::IID_CLOUDGAME_FIX_ZERO_CGFIX,(void**)&cf); //查询接口ID并设置接口
	if (SUCCEEDED(hr)) /*如果函数成功，cf将会指向一个子类对象，子类对象重写了接口的方法 */
	{
		cf->fixSystem(cgZero::Interface::cgFix::mode::cloudgame);
	}
	cf->Release();
	ptr->Release(); /*在生命周期结束时，释放ptr */
	return 0;
}
