﻿#pragma once
/*
MIT License

Copyright (c) 2023 eGlhb2p1emk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#include <map>
#include <io.h>
#include <stack>
#include <mutex>
#include <ctime>
#include <regex>
#include <array>
#include <format>
#include <string>
#include <thread>
#include <string>
#include <vector>
#include <chrono>
#include <atomic>
#include <conio.h>
#include <sstream>
#include <roapi.h>
#include <fstream>
#include <ShlObj.h>
#include <iostream>
#include <assert.h>
#include <iostream>
#include <WinUser.h>
#include <Windows.h>
#include <algorithm>
#include <stdexcept>
#include <strsafe.h>
#include <ShObjIdl.h>
#include <functional>
#include <filesystem>
#include <sdkddkver.h>
#include <wrl/event.h>
#include <yvals_core.h>
#include <propvarutil.h>
#include <source_location>
#include <wrl/implements.h>
#include <condition_variable>
#include <functiondiscoverykeys.h>
#include <windows.ui.notifications.h>
#include <Psapi.h>
#pragma comment(lib, "user32")
#pragma comment(lib, "shlwapi")
#pragma push_macro("new")

using namespace Microsoft::WRL;
using namespace ABI::Windows::Data::Xml::Dom;
using namespace ABI::Windows::Foundation;
using namespace ABI::Windows::UI::Notifications;
using namespace Windows::Foundation;

#ifndef CLOUDGAME_FIX_ZERO_H
#define CLOUDGAME_FIX_ZERO_H
#if _HAS_CXX20

namespace cgZero 
{
	//存储此库基本的信息
	namespace Infomation
	{
		static const HKEY HKCU = ((HKEY)(ULONG_PTR)((LONG)0x80000001));
		static const HKEY HKLM = ((HKEY)(ULONG_PTR)((LONG)0x80000002));
		static const HKEY HKCR = ((HKEY)(ULONG_PTR)((LONG)0x80000000));
		static LPCSTR author_Conf = "juzi xiao";
		static LPCSTR version_Conf = "cloudgame-fix_zero 2.05 pre-build zero Private | The C++ Edition";
		static LPCSTR __cg_Instance__ = "cloudgame-fix_zero 2.05 pre-build zero Private Instance : ";
		static LPCSTR versionConf = "cloudgame-fix_zero 2.10 pre-build zero Private sigma | The C++ Edition";
		static LPCSTR _USER_cloudpc = "netease";
		static LPCWSTR APPNAME = L"cloudgameFixZero";
		static LPCWSTR AUMI = L"cloudgameFixZero";
		//用于后期库的基本安全功能处理
		namespace Secutriy
		{
			static LPCSTR urlLinkRegex = "^(https://|http://|ftp://).+/.*";
		}
	}
	/* cgZero提供的单独句柄，用于实现日志库功能 */
	static const HANDLE CONSOLE_OUTPUT_HANDLE = GetStdHandle(STD_OUTPUT_HANDLE);

	/*用于特定类输出日志内容提供的简易函数，同时标识当前发布模式状态 .*/
	#ifdef NDEBUG
	static const bool IS_DEBUG = false;
	template<typename Ty>
	/**
	 * \brief 此部分写于2023/7/23.
	 * \brief 警告：如果要显示额外日志信息，请使用Debug发布模式而不是Realease
	 */
	inline void PrintError(Ty msg){}
	/**
	 * \brief 此部分写于2023/7/23.
	 * \brief 警告：如果要显示额外日志信息，请使用Debug发布模式而不是Realease
	 */
	template<typename Ty>
	void inline DEBUG_MESSAGE(Ty str) {}
	#else
	static const bool IS_DEBUG = true;
	/**
	 * \brief 此部分写于2023/7/23
	 * \brief 将调试信息打印到控制台，同时清除缓冲区.
	 * \brief 批注
	 * \brief 此函数与DEBUG_MESSAGE使用对象区别在于本函数使用std::wcerr
	 * \brief 如果std::wostream导出的对象接受msg的数据类型，则编译通过，否则编译失败
	 * \param msg 一个泛型参数
	 */
	template<typename Ty>
	void PrintError(Ty msg)
	{
		std::wcerr << msg;
		if (!std::wcerr.good()) {
			std::wcerr.clear();
			std::wcerr.imbue(std::locale("chs"));
			std::wcerr<<msg;
			std::wcerr.imbue(std::locale("C"));
		}
		std::wcerr << std::endl;
	}
	/**
	 * \brief 此部分写于2023/7/23
	 * \brief 将调试信息打印到控制台，同时清除缓冲区.
	 * \brief 批注
	 * \brief 此函数与PrintError使用对象区别在于本函数使用std::wcout
	 * \brief 如果std::wostream导出的对象接受msg的数据类型，则编译通过，否则编译失败
	 * \param msg 一个泛型参数
	 */
	template<class Ty>
	void DEBUG_MESSAGE(Ty str)
	{
		std::wcout << str;
		if (!std::wcout){
			std::wcout.clear();
			std::wcout.imbue(std::locale("chs"));
			std::wcout << str;
			std::wcout.imbue(std::locale("C"));
		}
		std::wcout << std::endl;
	}

	#endif //NDEBUG

	/* 基于jthread和Windows API封装的类 */
	class ThreadPlatform
	{
	public:
		using native_handle_type = std::thread::native_handle_type;
		
		ThreadPlatform() = delete;

		/**
		 * \brief 此部分写于2023/7/25
		 * \brief 有参构造函数
		 * \brief 设置对象的函数并初始化线程
		 * 
		 * \param f 一个指向任意函数的指针
		 * \param args 一个不定的参数列表
		 */
		template <typename Fn, typename... Args>
		explicit ThreadPlatform(Fn&& f, Args &&...args) : _suspend(true),Stop(false),_Start(false)
		{
			std::function<decltype(f(args...))()> func = std::bind(std::forward<Fn>(f), std::forward<Args>(args)...);
			this->func = [func]() {func(); };
		}

		virtual ~ThreadPlatform()
		{
			this->threadManager.request_stop();
			SuspendThread(this->native_handle());
			this->threadManager.detach();
		}

		/**
		 * \brief 此部分写于2023/7/25
		 * \brief 一个函数模板，用于设置函数并重置状态
		 * \brief 批注:
		 * \brief 此函数需要在线程已结束的前提下才能运行
		 * 
		 * \param f 一个指向任意函数的指针
		 * \param args 一个不定的参数列表
		 */
		template<typename Fn,typename ... Args>
		void LoadFunc(Fn&& f,Args && ...args)
		{
			if (this->_Start)
			{
				PrintError("检测到线程正在运行，无法重新加载函数 ");
				return;
			}
			std::function<decltype(f(args...))()> func = std::bind(std::forward<Fn>(f), std::forward<Args>(args)...);
			this->func = [func]()
			{
				func();
			};
			this->_suspend = true;
			this->Stop = false;
			this->_Start = false;
		}

		/**
		 * \brief 此部分写于2023/7/23.
		 * \brief 创建对象后，此函数将立即启动线程
		 * \brief 注意
		 * \brief 此函数如果已经执行，将不可再次调用，直到用户调用StopThread成员函数，否则会向控制台打印一行错误消息并直接return此成员函数
		 * \brief 同时保存一个句柄用于控制线程
		 * 
		 */
		inline void Start()
		{
			if (this->_Start)
			{
				PrintError("错误!线程已启动");
				return;
			}
			this->threadManager = std::jthread(this->func);
			this->_Start = true;
			this->_suspend = false;
		}

		/**
		 * \brief 此部分写于2023/7/23.
		 * \brief 此函数为Start成员函数的重载版本，此版本允许用户设置延时，此函数将调用异步线程，在延时结束时直接调用Start函数开启线程
		 * \brief 注意
		 * \brief 此函数如果已经执行，将不可再次调用，直到用户调用StopThread成员函数，否则会向控制台打印一行错误消息并直接return此成员函数
		 * \param milliseconds 休眠的毫秒数，数据类型为size_t
		 */
		inline void Start(size_t milliseconds)
		{
			if (this->_Start){
				PrintError("错误!线程已启动");
				return;
			}
			std::jthread tmp([this,milliseconds]() {
				std::this_thread::sleep_for(std::chrono::milliseconds(milliseconds));
				this->Start();
			});
			tmp.detach();
		}

		/**
		 * \brief 此部分写于2023/7/23.
		 * \brief 此函数将与主线程分离
		 * \brief 线程调用之后，此线程就成为守护线程，驻留后台运行，与之关联的线程对象将失去对目标线程的关联，无法再通过线程对象取得该线程的控制权。
		 * \brief 当线程主函数执行完之后，将自动清理。
		 * \brief 批注
		 * \brief 此函数还会影响以下成员函数
		 * \brief join(),StopThread(),get_id(),joinable()
		 * \brief 如果仅作为守护线程，请调用此函数，否则请谨慎使用
		 */
		inline void detach()
		{
			if (!this->_Start)
			{
				this->Start();
			}
			this->threadManager.detach();
			this->Detach = true;
		}

		/**
		 * \brief 此部分写于2023/7/23.
		 * \brief 获取该对象关联线程的原生系统句柄.
		 * 
		 * \return 如果线程启动则返回该对象关联线程的原生系统句柄，否则将返回NULL
		 */
		[[nodiscard]] native_handle_type native_handle() noexcept
		{
			if (this->_Start){
				return this->threadManager.native_handle();
			}
			else{
				return NULL;
			}
		}

		/**
		 * \brief 此部分写于2023/7/23.
		 * \brief 此函数将使线程合流，插入到主线程中，主线程将持续阻塞直到线程结束
		 */
		inline void join()
		{
			if (!this->_Start)
			{
				this->Start();
			}
			this->threadManager.join();
		}

		/**
		 * \brief 此部分写于2023/7/26.
		 * \brief 终止对象关联的线程
		 * \brief 批注
		 * \brief 如果用户运行了detach函数，此函数可能会出现异常
		 */
		void StopThread()
		{
			if (this->_Start){
				this->threadManager.request_stop();
				SuspendThread(this->native_handle());
				this->Stop = true;
				this->_Start = false;
			}
			else{
				PrintError("错误，线程需要启动后才能停止");
			}
		}

		/**
		 * \brief 此部分写于2023/7/26.
		 * \brief 此函数将会把该对象被挂起的关联线程恢复
		 * \brief 如果线程没有开启或没有挂起将会向控制台打印错误消息并return
		 */
		inline void Resume() noexcept 
		{
			if (this->_Start && !this->_suspend) {
				SuspendThread(this->threadManager.native_handle());
			}
			else {
				if (!this->_Start) {
					PrintError("线程没有启动，请问这是否是有意的");
				}
				else {
					PrintError("线程没有挂起，请问这是否是有意的");
				}
				return;
			}
		}

		/**
		 * \brief 此部分写于2023/7/26.
		 * \brief 此函数将会把该对象关联的进程挂起
		 * \brief 如果线程没有开启或已经挂起将会向控制台打印错误消息并return
		 */
		inline void Suspend() noexcept
		{
			if (this->_Start && !this->_suspend){
				SuspendThread(this->threadManager.native_handle());
			}
			else {
				if (!this->_Start) {
					PrintError("线程没有启动，请问这是否是有意的");
				}
				else {
					PrintError("线程已经挂起，请问这是否是有意的");
				}
				return;
			}
		}
		inline std::jthread& Get() noexcept { return this->threadManager; }
		inline bool joinable() noexcept { return threadManager.joinable(); }
		inline bool is_Stop() noexcept { return this->Stop; }
		inline std::jthread::id get_id() noexcept { return this->threadManager.get_id(); }
	private:
		std::jthread threadManager;
		std::function<void()> func;
		std::atomic_bool Stop;
		std::atomic_bool _suspend;
		std::atomic_bool Detach;
		bool _Start;
	};
	/* cloudgamefixZero的基础库命名空间，存放了程序需要的函数和常量 */
	namespace Foundation
	{
		/* 存储关于动态链接库的函数和常量 */
		namespace dynamincLibrayFunc
		{
			/* 预定义函数句柄 */
			static const HINSTANCE NTDLL =			GetModuleHandleW(L"NTDLL.dll");
			static const HINSTANCE USER32 =			LoadLibraryW(L"user32.dll");
			static const HINSTANCE KERNEL =			LoadLibraryW(L"kernel32.dll");
			static const HINSTANCE COMBASE =		LoadLibraryW(L"ComBase.dll");
			/* 预定义宏 */
			#define WINUEAPI WINAPI
			/* WINUEAPI是一个宏，全称WINDOWS_UN_EXTERN_API，即代表未提供声明或未文档化的函数 */

			/**
			 * \brief 此部分写于2023/7/25
			 * \brief 一个模板函数，用于将动态链接库的函数导出并绑定到函数指针.
			 * \param handle 动态链接库的句柄
			 * \param FuncName 函数名称
			 * \param pointer 函数指针
			 * \return 如果函数成功则返回S_OK，如果句柄有误，则返回E_INVALIDARG，如果函数名称有误或无法获取函数地址，则返回E_FAIL
			 */
			template<typename Fn>
			HRESULT WINAPI loadFunFromLib(HINSTANCE handle, LPCSTR FuncName, Fn& pointer)
			{
				if (!handle){
					return E_INVALIDARG;
				}
				else{
					pointer = reinterpret_cast<Fn>(GetProcAddress(handle, FuncName));
					if (pointer != nullptr){
						return S_OK;
					}
					else{
						PrintError("无法获取函数地址，您确定函数和句柄是对应的吗？");
						return E_FAIL;
					}
				}
			}
			namespace typePtr
			{
				typedef HRESULT(FAR WINUEAPI* type_SetCurrentProcessExplicitAppUserModelID)(__in PCWSTR AppID);
				typedef HRESULT(FAR WINUEAPI* type_PropVariantToString)(_In_ REFPROPVARIANT propvar, _Out_writes_(cch) PWSTR psz, _In_ UINT cch);
				typedef HRESULT(FAR WINUEAPI* type_RoGetActivationFactory)(_In_ HSTRING activatableClassId, _In_ REFIID iid,_COM_Outptr_ void** factory);
				typedef HRESULT(FAR WINUEAPI* type_WindowsCreateStringReference)(_In_reads_opt_(length + 1) PCWSTR sourceString, UINT32 length,_Out_ HSTRING_HEADER* hstringHeader,_Outptr_result_maybenull_ _Result_nullonfailure_ HSTRING* string);
				typedef PCWSTR(FAR WINUEAPI* type_WindowsGetStringRawBuffer)(_In_ HSTRING string, _Out_opt_ UINT32* length);
				typedef HRESULT(FAR WINUEAPI* type_WindowsDeleteString)(_In_opt_ HSTRING string);
			}

			/* 此命名空间提供了基于loadFunFromLib函数封装的未文档化/未导出函数 */
			namespace function
			{
				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 此函数属于未文档化Windows API
				 * \brief 
				 * \brief 获取Windows操作系统内部系统版本号
				 * \param dwMajor 指向DWORD(32位无符号整数)的地址，用于接收NT内核版本
				 * \param dwMinor 指向DWORD(32位无符号整数)的地址
				 * \param dwBuilder 指向DWORD(32位无符号整数)的地址，用于接收Windows构建版本号
				 * \return 
				 */
				static VOID WINAPI RtlGetNtVersionNumbers(_Inout_ DWORD* dwMajor, _Inout_ DWORD* dwMinor, _Inout_ DWORD* dwBuilder){
					void(WINAPI * func)(DWORD*, DWORD*, DWORD*) = nullptr;
					if (HRESULT hr = loadFunFromLib(NTDLL, "RtlGetNtVersionNumbers", func); SUCCEEDED(hr)) {
						func(dwMajor, dwMinor, dwBuilder);
					}
				}

				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 在MessageBoxA原有的功能上提供了超时功能，如果达到用户传入参数时间，则自动关闭
				 * \brief 批注：
				 * \brief 以下参数中hWnd,lpText,lpCaption,uType参数
				 * \brief 请参考以下链接:
				 * \brief https://learn.microsoft.com/zh-cn/windows/win32/api/winuser/nf-winuser-messageboxa
				 * \param hWnd 参考链接文档
				 * \param lpText 参考链接文档
				 * \param lpCaption 参考链接文档
				 * \param uType 参考链接文档
				 * \param wLanguageId 语言ID，通常情况下请设置为NULL或者0即可
				 * \param dwMilliseconds 超时时间，单位毫秒
				 * \return 返回值同MessageBoxA
				 */
				static int WINUEAPI MessageBoxTimeoutA(_In_ HWND hWnd, _In_ LPCSTR lpText, _In_ LPCSTR lpCaption, _In_ UINT uType, _In_ WORD wLanguageId, _In_ DWORD dwMilliseconds)
				{
					int (WINAPI * MessageBoxTimeOut_)(HWND, LPCSTR, LPCSTR, UINT, WORD, DWORD);
					if (HRESULT hr = loadFunFromLib(USER32, "MessageBoxTimeoutA", MessageBoxTimeOut_);SUCCEEDED(hr)) {
						if (hWnd == NULL){
							hWnd = GetForegroundWindow();
							return MessageBoxTimeOut_(hWnd, lpText, lpCaption, uType, wLanguageId, dwMilliseconds);
						}
						else{
							return MessageBoxTimeOut_(hWnd, lpText, lpCaption, uType, wLanguageId, dwMilliseconds);
						}
					}
					DEBUG_MESSAGE("加载失败");
					return NULL;
				}

				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 在MessageBoxW原有的功能上提供了超时功能，如果达到用户传入参数时间，则自动关闭
				 * \brief 批注：
				 * \brief 以下参数中hWnd,lpText,lpCaption,uType参数
				 * \brief 请参考以下链接:
				 * \brief https://learn.microsoft.com/zh-cn/windows/win32/api/winuser/nf-winuser-messageboxw
				 * \param hWnd 参考链接文档
				 * \param lpText 参考链接文档
				 * \param lpCaption 参考链接文档
				 * \param uType 参考链接文档
				 * \param wLanguageId 语言ID，通常情况下请设置为NULL或者0即可
				 * \param dwMilliseconds 超时时间，单位毫秒
				 * \return 返回值同MessageBoxW
				 */
				static int WINUEAPI MessageBoxTimeoutW(_In_ HWND hWnd, _In_ LPCWSTR lpText, _In_ LPCWSTR lpCaption, _In_ UINT uType, _In_ WORD wLanguageId, _In_ DWORD dwMilliseconds){
					int (WINAPI * MessageBoxTimeOut_)(HWND, LPCWSTR, LPCWSTR, UINT, WORD, DWORD) = nullptr;
					if (HRESULT hr = loadFunFromLib(USER32, "MessageBoxTimeoutW", MessageBoxTimeOut_);SUCCEEDED(hr)){
						if (hWnd == NULL){
							hWnd = GetForegroundWindow();
							return MessageBoxTimeOut_(hWnd, lpText, lpCaption, uType, wLanguageId, dwMilliseconds);
						}
						else{
							return MessageBoxTimeOut_(hWnd, lpText, lpCaption, uType, wLanguageId, dwMilliseconds);
						}
					}
					return -1;
				}

				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 基于指定的字符串创建新的字符串引用。
				 * \brief 批注：
				 * \brief 此函数属于未导出函数，已经文档化，关于文档信息
				 * \brief 请参考以下链接：
				 * \brief https://learn.microsoft.com/zh-cn/windows/win32/api/winstring/nf-winstring-windowscreatestringreference
				 * \param sourceString 
				 * \param 一个以 null 结尾的字符串，用作新 HSTRING 的源。如果长度为 0，则 NULL 值表示空字符串。 应在堆栈帧上分配
				 * \param length
				 * \param SourceString 的长度（以 Unicode 字符为单位）。 如果 sourceString 为 NULL，则必须为 0。 如果大于 0， sourceString 必须具有终止 null 字符
				 * \param hstringHeader
				 * \param 指向Windows 运行时用来将字符串标识为字符串引用或快速传递字符串的结构的指针。
				 * \param string
				 * \param 指向新创建的字符串的指针;如果发生错误,则为 NULL,将覆盖 字符串 中的任何现有内容,HSTRING 是标准句柄类型
				 * \returns 成功
				 * \returns S_OK			已成功创建 [**HSTRING**] (/windows/win32/winrt/hstring)
				 * \returns 失败
				 * \returns E_INVALIDARG	字符串或 hstringHeader 为 NULL，或者字符串不是以null结尾的
				 * \returns E_OUTOFMEMORY	未能分配新的 [**HSTRING**] (/windows/win32/winrt/hstring)
				 * \returns E_POINTER		sourceString为NULL,长度为非零
				 */
				inline HRESULT FAR WINUEAPI WindowsCreateStringReference(PCWSTR sourceString, UINT32 length, HSTRING_HEADER* hstringHeader, HSTRING* string) {
					HRESULT(FAR STDAPICALLTYPE * f_WindowsCreateStringReference)(PCWSTR, UINT32, _Out_ HSTRING_HEADER*, HSTRING*) = nullptr;
					loadFunFromLib(COMBASE, "WindowsCreateStringReference", f_WindowsCreateStringReference);
					return f_WindowsCreateStringReference(sourceString, length, hstringHeader, string);
				}

				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 检索指定字符串的后盾缓冲区。
				 * \brief 批注：
				 * \brief 此函数属于未导出函数，已经文档化，关于文档信息
				 * \brief 请参考以下链接：
				 * \brief https://learn.microsoft.com/zh-cn/windows/win32/api/winstring/nf-winstring-windowsgetstringrawbuffer
				 * \param string 要为其检索后退缓冲区的可选字符串,可以为 NULL
				 * \param length 
				 * \param 指向UINT32的可选指针。如果为长度传递NULL，则忽略NULL
				 * \param 如果长度是指向UINT32的有效指针，并且字符串是有效的HSTRING，则在成功完成后，该函数会将值设置为字符串后退缓冲区中Unicode字符数(（包括嵌入的null字符），但不包括终止null) 
				 * \param 如果length是指向UINT32的有效指针，并且字符串为NULL，则按 长度 指向的值设置为 0。
				 * \return 返回指向为 字符串提供后盾存储的缓冲区的指针;如果字符串为NULL或空字符串，则为空字符串。
				 */
				inline PCWSTR FAR WINUEAPI WindowsGetStringRawBuffer(_In_ HSTRING string, UINT32* length){
					PCWSTR(FAR STDAPICALLTYPE * f_WindowsGetStringRawBuffer)(_In_ HSTRING string, _Out_opt_ UINT32 * length);
					loadFunFromLib(COMBASE, "WindowsGetStringRawBuffer", f_WindowsGetStringRawBuffer);
					return f_WindowsGetStringRawBuffer(string, length);
				}

				/**
				 * \brief 此部分写于2023/7/25.
				 * \brief 递减字符串缓冲区的引用计数。
				 * \brief 批注：
				 * \brief 此函数属于未导出函数，已经文档化，关于文档信息
				 * \brief 请参考以下链接：
				 * \brief https://learn.microsoft.com/zh-cn/windows/win32/api/winstring/nf-winstring-windowsdeletestring
				 * 
				 * \param string 要删除的字符串
				 * \param 如果 字符串 是由 WindowsCreateStringReference创建的快速传递字符串或者如果字符串为NULL或空，则不执行任何操作并返回S_OK
				 * \return 此函数无论如何必定会返回一个S_OK
				 */
				inline HRESULT FAR WINUEAPI WindowsDeleteString(_In_opt_ HSTRING string){
					HRESULT(FAR STDAPICALLTYPE * f_WindowsDeleteString)(_In_opt_ HSTRING string);
					HINSTANCE Handle = LoadLibraryW(L"Combase.dll");
					if (Handle){
						loadFunFromLib(Handle, "WindowsDeleteString", f_WindowsDeleteString);
						FreeLibrary(Handle);
						return f_WindowsDeleteString(string);
					}
					return S_FALSE;
				}


				inline HRESULT FAR WINUEAPI PropVariantToString(_In_ REFPROPVARIANT propvar, PWSTR psz, _In_ UINT cch) {
					HRESULT(FAR STDAPICALLTYPE * f_PropVariantToString)(_In_ REFPROPVARIANT propvar, _Out_writes_(cch) PWSTR psz, _In_ UINT cch) = nullptr;
					loadFunFromLib(COMBASE, "WindowsDeleteString", f_PropVariantToString);
					return f_PropVariantToString(propvar, psz, cch);
				}
				/**
				* 
				 * 此函数RoGetActivationFactory的封装，用于获取指定运行时类的激活工厂。
				 * \brief 批注：
				 * \brief 此函数属于未导出函数，已经文档化，关于文档信息
				 * \brief 请参考以下链接:
				 * 
				 * \param activatableClassId 可激活类的GUID
				 * \param factory 激活工厂
				 * \return 如果此函数成功，它将返回S_OK。否则，它将返回HRESULT错误代码。
				 */
				template<typename Factory>
				inline HRESULT FAR WINUEAPI Wrap_GetActivationFactory(_In_ HSTRING activatableClassId, _Inout_ Microsoft::WRL::Details::ComPtrRef<Factory> factory){
					HRESULT(FAR STDAPICALLTYPE * func)(HSTRING, const IID&, void**) = nullptr;
					loadFunFromLib(COMBASE, "RoGetActivationFactory", func);
					return func(activatableClassId, IID_INS_ARGS(factory.ReleaseAndGetAddressOf()));
				}

				/**
				 * 此函数用于获取系统版本信息.
				 * \brief 批注：
				 * \brief 此函数属于未导出，未文档化函数
				 * 
				 * \return 如果函数成功，它将返回类型RTL_OSVERSIONINFOW的结构体
				 */
				inline static RTL_OSVERSIONINFOW FAR WINUEAPI RtlGetVersion() {
					NTSTATUS(WINAPI * RtlGetVersionPtr)(PRTL_OSVERSIONINFOW) = nullptr;
					if (SUCCEEDED(loadFunFromLib(NTDLL, "RtlGetVersion", RtlGetVersionPtr)))
					{
						RTL_OSVERSIONINFOW rovi = { 0 };
						rovi.dwOSVersionInfoSize = sizeof(rovi);
						if (RtlGetVersionPtr(&rovi) == (0x00000000)) {
							return rovi;
						}
					}
					RTL_OSVERSIONINFOW rovi = { 0 };
					return rovi;
				}

				/* 此命名空间存储了可能会导致敏感行为的Windows未导出API和这些API可能需要的常量. */
				namespace unstable
				{
					enum SePrivilege : ULONG 
					{
						SeUnsolicitedInputPrivilege = 0x00,
						SeUnknownInvalidPrivilege = 0x01,
						SeCreateTokenPrivilege = 0x02,
						SeAssignPrimaryTokenPrivilege = 0x03,
						SeLockMemoryPrivilege = 0x04,
						SeIncreaseQuotaPrivilege = 0x05,
						SeMachineAccountPrivilege = 0x06,
						SeTcbPrivilege = 0x07,
						SeSecurityPrivilege = 0x08,
						SeTakeOwnershipPrivilege = 0x09,
						SeLoadDriverPrivilege = 0x0A,
						SeSystemProfilePrivilege = 0x0B,
						SeSystemtimePrivilege = 0x0C,
						SeProfileSingleProcessPrivilege = 0x0D,
						SeIncreaseBasePriorityPrivilege = 0x0E,
						SeCreatePagefilePrivilege = 0x0F,
						SeCreatePermanentPrivilege = 0x10,
						SeBackupPrivilege = 0x11,
						SeRestorePrivilege = 0x12,
						SeShutdownPrivilege = 0x13,
						SeDebugPrivilege = 0x14,
						SeAuditPrivilege = 0x15,
						SeSystemEnvironmentPrivilege = 0x16,
						SeChangeNotifyPrivilege = 0x17,
						SeRemoteShutdownPrivilege = 0x18,
						SeUndockPrivilege = 0x19,
						SeSyncAgentPrivilege = 0x1A,
						SeEnableDelegationPrivilege = 0x1B,
						SeManageVolumePrivilege = 0x1C,
						SeImpersonatePrivilege = 0x1D,
						SeCreateGlobalPrivilege = 0x1E,
						SeTrustedCredManAccessPrivilege = 0x1F,
						SeRelabelPrivilege = 0x20,
						SeIncreaseWorkingSetPrivilege = 0x21,
						SeTimeZonePrivilege = 0x22,
						SeCreateSymbolicLinkPrivilege = 0x23,
						SeDelegateSessionUserImpersonatePrivilege =0x24
					};

					/**
					 * 提升进程的访问权限.
					 * 
					 * \param Privilege 权限id
					 * \param bEnablePrivilege 如果为TRUE,则开启权限，反之关闭
					 * \param IsThreadPrivilege 如果为TRUE,则仅提升当前线程权限，否则提升整个进程的权限
					 * \param PreviousValue 输出原来相应权限的状态（打开 | 关闭）
					 * \return 可忽略
					 */
					static UINT RtlAdjustPrivilege(ULONG Privilege, BOOL bEnablePrivilege, BOOL IsThreadPrivilege, PINT PreviousValue)
					{
						UINT(CALLBACK* f_RtlAdjustPrivilege)(ULONG, BOOL, BOOL, PINT) = nullptr;
						if (HRESULT hr = loadFunFromLib(NTDLL,"RtlAdjustPrivilege",f_RtlAdjustPrivilege); SUCCEEDED(hr)) {
							return f_RtlAdjustPrivilege(Privilege, bEnablePrivilege, IsThreadPrivilege, PreviousValue);
						}
						else {
							return -1;
						}
					}
				}
			}
		}
		/* cgZero提供的简易工具集合 */
		namespace Tool
		{
			/* 提供了简易的函数工具 */
			namespace function
			{
				/**
				 * 此函数运行用户获取Windows环境变量的值.
				 * 
				 * \param PATH 环境变量值，一个字符串类型，如APPDATA
				 * \param len 长度（可选）
				 * \return 如果一切正常，函数将返回一个std::string类型的容器，里面存储的是环境变量对应的值
				 */
				inline static std::string _GetEnvironmentVariableA(const std::string PATH, DWORD len = MAX_PATH)
				{
					char* buf = {};
					len = ::GetEnvironmentVariableA(PATH.c_str(), buf, 0);
					char* buffer = new char[len];
					*buffer = { '\0' };
					::GetEnvironmentVariableA(PATH.c_str(), buffer, len);
					std::string ret = buffer;
					*buffer = NULL;
					delete[] buffer;
					return ret;
				}

				/**
				 * 此函数将从注册表中获取关于处理器的字符串.
				 * 
				 * \return 如果一切正常，将返回一个CHAR*字符串
				 */
				inline static CHAR* GetProcesserFromRegistryA()
				{
					HKEY HANDLES;
					RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", NULL, KEY_ALL_ACCESS, &HANDLES);
					char* lpbuffer = new char[50];
					DWORD dwSize = 50;
					RegGetValueA(HANDLES, NULL, "ProcessorNameString", RRF_RT_ANY, NULL, lpbuffer, &dwSize);
					RegCloseKey(HANDLES);
					return lpbuffer;
				}

				/**
				 * 此函数将从注册表中获取关于处理器的宽字符串.
				 * 
				 * \return 如果一切正常，将返回一个WCHAR*字符串
				 */
				inline static WCHAR* GetProcesserFromRegistryW()
				{
					HKEY HANDLES;
					RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", NULL, KEY_ALL_ACCESS, &HANDLES);
					WCHAR* lpbuffer = new WCHAR[50];
					DWORD dwSize = 50;
					RegGetValueW(HANDLES, NULL, L"ProcessorNameString", RRF_RT_ANY, NULL, lpbuffer, &dwSize);
					RegCloseKey(HANDLES);
					return lpbuffer;
				}

				/**
				 * 此函数将从系统中获取当前登录的用户名.
				 * 
				 * \return 如果一切正常将返回LPCSTR类型的指针，指针存储的是用户名
				 */
				inline static LPCSTR GetUserA()
				{
					static char username[1024];
					DWORD usernameLength = sizeof(username);
					GetUserNameA(username, &usernameLength);
					return username;
				}

				/**
				 * 此函数将从系统中获取当前登录的用户名.
				 * 
				 * \return 如果一切正常将返回LPCWSTR类型的指针，指针存储的是用户名
				 */
				inline static LPCWSTR GetUserW()
				{
					static wchar_t username[1024];
					DWORD usernameLength = 1024;
					GetUserNameW(username, &usernameLength);
					return username;
				}

				/**
				 * 此函数的行为类似于pause指令.
				 * 
				 * \param message 提示信息，如果提示信息为NULL，则什么都不打印
				 * \param wrap 决定是否换行，默认为true，如果为false将不打印换行符
				 * \param 注：如果message为NULL，则wrap即使为true或者false，都不会换行
				 * 
				 */
				static void PRESSANYBOTTON(const char* message = "请按任意键继续...", bool wrap = true)
				{
					if (message == NULL)
					{
						std::cout << "";
						int tmp = _getch();
						return;
					}
					else
					{
						std::cout << message;
					}
					int tmp = _getch();
					if (wrap)
					{
						std::cout.put('\n');
					}
					return;
				}
			}
			namespace CONSOLE
			{
				namespace Property
				{
					enum : WORD {
						CONSOLE_COLOR_BLACK = 0x0000,
						CONSOLE_COLOR_BLUE = 0x0001,
						CONSOLE_COLOR_GREEN = 0x0002,
						CONSOLE_COLOR_AQUA = 0x0003,
						CONSOLE_COLOR_RED = 0x0004,
						CONSOLE_COLOR_PURPLE = 0x0005,
						CONSOLE_COLOR_YELLOW = 0x0006,
						CONSOLE_COLOR_WHITE = 0x0007,
						CONSOLE_COLOR_GRAY = 0x0008,
						CONSOLE_COLOR_LIGHTBULE = 0x0009,
						CONSOLE_COLOR_LIGHTGREEN = 0xA,
						CONSOLE_COLOR_LIGHTAQUA = 0xB,
						CONSOLE_COLOR_LIGHTRED = 0xC,
						CONSOLE_COLOR_LIGHTPURPLE = 0xD,
						CONSOLE_COLOR_LIGHTYELLOW = 0xE,
						CONSOLE_COLOR_BRIGHTWHITE = 0xF
					};
				}
				inline BOOL SetConsoleTextAttribute(bool render, HANDLE handle, WORD color){
					if (render && handle){
						return ::SetConsoleTextAttribute(handle, color);
					}
					else{
						return FALSE;
					}
				}
			}
		}
		namespace Warpper
		{
			class HstringWrapper
			{
			public:
				HstringWrapper(_In_reads_(length) PCWSTR stringRef, _In_ UINT32 length) noexcept
				{
					HRESULT hr = dynamincLibrayFunc::function::WindowsCreateStringReference(stringRef, length, &header, &hstring);
					if (!SUCCEEDED(hr)){
						RaiseException(static_cast<DWORD>(STATUS_INVALID_PARAMETER), EXCEPTION_NONCONTINUABLE, 0, nullptr);
					}
				}
				HstringWrapper(_In_ std::wstring const& stringRef) noexcept
				{
					HRESULT hr = dynamincLibrayFunc::function::WindowsCreateStringReference(stringRef.c_str(), static_cast<UINT32>(stringRef.length()), &header, &hstring);
					if (FAILED(hr)){
						RaiseException(static_cast<DWORD>(STATUS_INVALID_PARAMETER), EXCEPTION_NONCONTINUABLE, 0, nullptr);
					}
				}
				~HstringWrapper(){dynamincLibrayFunc::function::WindowsDeleteString(hstring);}
				inline HSTRING Get() const noexcept{return this->hstring;}
			private:
				HSTRING hstring;
				HSTRING_HEADER header;
			};

			class InternalDateTime : public ABI::Windows::Foundation::IReference<ABI::Windows::Foundation::DateTime>
			{
			public:
				static INT64 Now() {
					FILETIME now;
					GetSystemTimeAsFileTime(&now);
					return ((((INT64)now.dwHighDateTime) << 32) | now.dwLowDateTime);
				}
				InternalDateTime(ABI::Windows::Foundation::DateTime dateTime) : _dateTime(dateTime) { this->AddRef(); }
				InternalDateTime(INT64 millisecondsFromNow) { this->_dateTime.UniversalTime = Now() + millisecondsFromNow * 10000; }
				virtual ~InternalDateTime() = default;
				operator INT64() { return _dateTime.UniversalTime; }
				virtual HRESULT STDMETHODCALLTYPE get_Value(ABI::Windows::Foundation::DateTime* dateTime) {
					*dateTime = _dateTime;
					return S_OK;
				}
				virtual HRESULT STDMETHODCALLTYPE QueryInterface(const IID& riid, void** ppvObject) {
					if (!ppvObject)
					{
						return E_POINTER;
					}
					if (riid == __uuidof(IUnknown) || riid == __uuidof(IReference<ABI::Windows::Foundation::DateTime>))
					{
						*ppvObject = static_cast<IUnknown*>(static_cast<IReference<ABI::Windows::Foundation::DateTime>*>(this));
						return S_OK;
					}
					return E_NOINTERFACE;
				}
				virtual ULONG STDMETHODCALLTYPE Release() {
					if (this->ref--; this->ref == 0) {
						delete this;
					}
					else {
						return this->ref;
					}
					return NULL;
				}

				virtual ULONG STDMETHODCALLTYPE AddRef() { this->ref++; return this->ref; }
				virtual HRESULT STDMETHODCALLTYPE GetIids(ULONG*, IID**) { return E_NOTIMPL; }
				virtual HRESULT STDMETHODCALLTYPE GetRuntimeClassName(HSTRING*) { return E_NOTIMPL; }
				virtual inline HRESULT STDMETHODCALLTYPE GetTrustLevel(TrustLevel*) { return E_NOTIMPL; }
			protected:
				ABI::Windows::Foundation::DateTime _dateTime;
				ULONG ref = NULL;
			};
		}
	}

	/* 所有来自cloudgamefixZero库定义的接口均来自此命名空间 .*/
	namespace Interface
	{
		#define ZERO_DEPRECATED_FUNC(reason) [[deprecated(reason)]]
		/* 异常类命名空间 */
		namespace Exceptions
		{
			//当接口传入了错误参数时，此异常将会被激活
			class errorArgs : public std::logic_error
			{
			public:
				using _Mybase = std::logic_error;
				explicit errorArgs(const char* msg) : _Mybase(msg) {}
				explicit errorArgs(std::string msg) : _Mybase(msg.c_str()) {}
			};
			//当接口传入类似reserved的值时，此异常将会被激活
			class reservedArgs : public std::logic_error
			{
			public:
				using _Mybase = std::logic_error;
				explicit reservedArgs(const char* msg) : _Mybase(msg) {}
				explicit reservedArgs(std::string msg) : _Mybase(msg.c_str()) {}
			};
			//当用户尝试禁用安全检查并调用启用的函数时，此异常将会被激活
			class deprecatedFunction : public std::logic_error
			{
			public:
				using _Mybase = std::logic_error;
				explicit deprecatedFunction(const char* msg) : _Mybase(msg) {}
				explicit deprecatedFunction(std::string msg) : _Mybase(msg.c_str()) {}
			};
			class rangeOut : public std::logic_error
			{
			public:
				using _Mybase = std::logic_error;
				explicit rangeOut(const char* msg) : _Mybase(msg) {}
				explicit rangeOut(std::string msg) : _Mybase(msg.c_str()) {}
			};
			//当用户尝试禁用安全检查并调用启用的函数时，此异常将会被激活
			class nullPointer : public std::logic_error
			{
			public:
				using _Mybase = std::logic_error;
				explicit nullPointer(const char* msg) : _Mybase(msg) {}
				explicit nullPointer(std::string msg) : _Mybase(msg.c_str()) {}
			};
		}
	}

	#pragma region LOGSYSTEM
	enum logLevel : UINT {Reserved,Trace,Info,WARN,Debug,FATAL,Error};

	struct LOGGLOBALOPT
	{
		bool autoInit = false;
		bool Enable = true;
		bool OutPut = true;
		bool Save = true;
		bool NoPreOutPut = false;
		bool showDetail = true;
		bool ShowTime = true;
		bool ShowUser = true;
		bool Render = true;
		std::string filename = std::string();
		std::string filepath = std::string();
		std::string FileFormatTime = "[%Y %m %d]";
		std::string LogFormatTime = "[%Ec %A]";
	};
	
	static const LOGGLOBALOPT defaultOption;

	class zeroLog
	{
	public:
		friend class logger;
		zeroLog(bool init, LOGGLOBALOPT option = defaultOption) : UserOption(option){
			if (init){
				this->Init();
			}
		}
		zeroLog(bool init, bool useStacks = true, LOGGLOBALOPT option = defaultOption) : UserOption(option){
			this->status = useStacks;
			if (init){
				this->Init();
			}
		}
		zeroLog(bool init, std::string path = std::string(), bool useStacks = false, LOGGLOBALOPT option = defaultOption) : UserOption(option),filepath(path){
			this->status = useStacks;
			if (init){
				this->Init();
			}
		}
		zeroLog& operator=(const zeroLog& other)								= delete;
		inline zeroLog(const zeroLog& other)									= delete;
		virtual ~zeroLog()														{ this->logbuffer.clear();this->buffer.clear();this->filepath.clear();this->closeSystem(); }
		inline BOOL IsInit()													{ return this->isinit; }
		virtual inline zeroLog& setLocation(_In_ std::string path) noexcept		{ this->filepath = path; return *this; }
		virtual inline zeroLog& setFileName(_In_ std::string name) noexcept		{ this->savename = name; return *this; }
		inline std::string GetLastLog()											{ return this->logbuffer; }
		inline void GetLastLog(std::string& msg)								{ msg = this->logbuffer; }


		BOOL Init()
		{
			if (this->UserOption.Enable)
			{
				if (this->IsInit())
				{
					DEBUG_MESSAGE("错误，对象已初始化");
					return FALSE;
				}
				std::string logPath;
				if (!this->filepath.empty())
				{
					logPath = this->filepath;
					if (std::filesystem::exists(logPath))
					{
						DEBUG_MESSAGE("已经确认目录，跳过创建");
					}
					else
					{
						DEBUG_MESSAGE("目录不存在!");
						std::filesystem::create_directories(logPath);
					}
				}
				logPath += savename;
				if (this->UserOption.Save)
				{
					this->logSystemObject.open(logPath.c_str(), std::ios::out);
					if (!this->logSystemObject.is_open()) {
						DEBUG_MESSAGE("警告，无法打开文件或者没有设置");
					}
				}
				DEBUG_MESSAGE("初始化成功");
				DEBUG_MESSAGE("开始记录日志");
			}
			else
			{
				std::cerr << "无法初始化，请确认配置变量中是否启用" << "\n";
				return FALSE;
			}
			this->isinit = true;
			return TRUE;
		}
		

		zeroLog& write(_In_ logLevel reportLevel, _Inout_ LPCSTR txt,const bool show = true, const std::source_location location = std::source_location::current())
		{
			this->ThreadLock.lock();
			std::stringstream stream;
			logLevels level{};
			stream << level.get_Str(reportLevel) << (this->UserOption.ShowUser ? " " : "") << (this->UserOption.ShowUser ? cgZero::Foundation::Tool::function::GetUserA() : "") << (" " + (this->UserOption.ShowTime ? this->getTime(this->UserOption.LogFormatTime) : std::string()).append(": ").append(txt));
			if (this->IsInit())
			{
				this->logbuffer = stream.str();
				if (show && this->UserOption.OutPut)
				{
					if (this->UserOption.OutPut) {
						this->WriteMessage(reportLevel, this->logbuffer);
					}
				}
				if (this->UserOption.Save) {
					std::string detail = std::format("{} {} {} ", location.function_name(), location.line(), location.file_name());
					std::string text = std::format("{}{}", (this->UserOption.showDetail ? detail : ""), txt);
					this->logSystemObject << text << std::endl;
				}
				if (this->status) {
					this->stacks.push(this->logbuffer);
				}
				else {
					this->buffer.push_back(this->logbuffer);
				}
				if (this->status) {
					this->stacks.push(this->logbuffer);
				}
				else {
					this->buffer.push_back(this->logbuffer);
				}
			}
			else
			{
				DEBUG_MESSAGE("未初始化");
			}
			this->ThreadLock.unlock();
			return *this;
		}

		inline zeroLog& write(_In_ logLevel reportLevel, _Inout_ std::string txt,const bool show = true, const std::source_location location = std::source_location::current()){return this->write(reportLevel, txt.c_str(), show, location);}
		virtual inline zeroLog& operator()(logLevel level)
		{
			this->ThreadLock.lock();
			if (level == logLevel::Reserved)
			{
				this->ThreadLock.unlock();
				throw Interface::Exceptions::reservedArgs("保留值不可用");
			}
			this->tempLevel = level;
			this->ThreadLock.unlock();
			return *this;
		}
		virtual inline zeroLog& operator<<(LPCSTR txt)
		{
			this->ThreadLock.lock();
			if (!this->IsInit())
			{
				DEBUG_MESSAGE("需要初始化");
				this->ThreadLock.unlock();
				return *this;
			}
			std::stringstream stream;
			logLevels level{};
			if (this->tempLevel == logLevel::Reserved)
			{
				this->ThreadLock.unlock();
				throw Interface::Exceptions::reservedArgs("保留值不可用");
			}
			stream << level.get_Str(this->tempLevel) << (this->UserOption.ShowUser ? " " : "") << (this->UserOption.ShowUser ? cgZero::Foundation::Tool::function::GetUserA() : "") << (" " + (this->UserOption.ShowTime ? this->getTime(this->UserOption.LogFormatTime) : std::string()).append(": ").append(txt));
			this->logbuffer = stream.str();
			if (this->UserOption.OutPut) {
				this->WriteMessage(this->tempLevel, this->logbuffer);
			}
			if (this->UserOption.Save) {
				this->logSystemObject << this->logbuffer << std::endl;
			}
			if (this->status) {
				this->stacks.push(this->logbuffer);
			}
			else {
				this->buffer.push_back(this->logbuffer);
			}
			this->ThreadLock.unlock();
			return *this;
		}
		virtual zeroLog& closeSystem()
		{
			if (this->IsInit())
			{
				DEBUG_MESSAGE("开始关闭对象实例");
				this->logSystemObject.close();
				this->realseCache();
				DEBUG_MESSAGE("正在重置初始化状态");
				this->isinit = false;
			}
			return *this;
		}
		zeroLog& writeInitMessage(){
			if (!this->UserOption.NoPreOutPut && this->IsInit()){
				char* lpbuffer = Foundation::Tool::function::GetProcesserFromRegistryA();
				DWORD one = NULL, two = NULL, three = NULL;
				Foundation::dynamincLibrayFunc::function::RtlGetNtVersionNumbers(&one, &two, &three);
				char user[1024];
				DWORD usernameLength = sizeof(user);
				GetUserNameA(user, &usernameLength);
				this->logSystemObject << "Processer -> " << lpbuffer << std::endl;
				this->logSystemObject << "User -> " << user << std::endl;
				this->logSystemObject << "Time -> " << this->getTime(this->UserOption.FileFormatTime) << std::endl;
				this->logSystemObject << "OS_VER -> " << one << std::endl;
				this->logSystemObject << "Build_VER -> " << three << std::endl;
				this->logSystemObject << "VERSION -> " << cgZero::Infomation::versionConf << "\n" << std::endl;
				*user = NULL;
			}
			else {
				DEBUG_MESSAGE("设置禁用了NoPreOutPut");
			}
			return *this;
		}
		zeroLog& writeErrorMessage(logLevel reportLevel, DWORD ret)
		{
			char buf[1024] = "\0";
			FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, ret, 0, buf, sizeof(buf), NULL);
			return this->write(reportLevel, buf);
		}
		static char* formatErrorMessage(DWORD ret)
		{
			static char buf[1024] = "\0";
			FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, ret, 0, buf, sizeof(buf), NULL);
			return buf;
		}
		static zeroLog* Instance()
		{
			static zeroLog CLOUDGAME_FIX_ZERO_LOGOBJECT(false, GetLogPathHelper());
			if (!CLOUDGAME_FIX_ZERO_LOGOBJECT.IsInit())
			{
				CLOUDGAME_FIX_ZERO_LOGOBJECT.setFileName(GetFileNameHelper());
			}
			return &CLOUDGAME_FIX_ZERO_LOGOBJECT;
		}
		inline void realseCache() {
			if (this->status)
			{
				if (this->stacks.empty())
				{
					DEBUG_MESSAGE("确认收到缓存内容，准备清理信息");
					while (!this->stacks.empty()) { this->stacks.pop(); }
					DEBUG_MESSAGE("清理完毕");
					return;
				}
				else
				{
					DEBUG_MESSAGE("未收到缓存内容，跳过执行");
					return;
				}
			}
			else
			{
				if (this->buffer.empty()){
					DEBUG_MESSAGE("确认收到缓存内容，准备清理信息");
					this->buffer.clear();
					DEBUG_MESSAGE("清理完毕");
					return;
				}
				else{
					DEBUG_MESSAGE("未收到缓存内容，跳过执行");
					return;
				}
			}
		}
		void showVectorLog() {
			std::cout << "log日志的缓存中共有" << this->buffer.size() << "条日志" << std::endl;
			std::cout << "以下是已经记录的日志" << std::endl;
			std::for_each(this->buffer.begin(), this->buffer.end(), []<typename str>(str lpbuffer) { std::cout << "log -> " << lpbuffer << std::endl; });
			std::cout << "文件内容在: " << (this->filepath.empty() ? GetLogPathHelper() : this->filepath) << std::endl;
			return;
		}
		void clearAndShowStackLog() {
			std::cout << "log日志的缓存共有" << this->stacks.size() << "条日志" << std::endl;
			std::cout << "以下是已经记录的日志" << std::endl;
			while (!this->stacks.empty())
			{
				std::cout << "log -> " << stacks.top() << std::endl;
				this->stacks.pop();
			}
			std::cout << "文件内容在: " << (this->filepath.empty() ? GetLogPathHelper() : this->filepath) << std::endl;
			std::cout << "提示：栈获取到的数据属于出栈后得到的数据，执行函数后栈将被清空" << std::endl;
			return;
		}
		inline void enableColor() {this->UserOption.Render = true;}
		inline void disableColor() {this->UserOption.Render = false;}
		std::string current_Log_Path;
	protected:
		std::vector<std::string> buffer;
		std::string logbuffer;
		std::stack<std::string> stacks;
		bool status = false;
		std::string filepath = std::string();
		std::string savename = std::string();
	private:
		std::mutex ThreadLock;
		LOGGLOBALOPT UserOption;
		logLevel tempLevel = logLevel::Reserved;
		bool isinit = false;
		static std::string getTime(std::string format)
		{
			std::time_t tt = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
			std::tm tms;
			gmtime_s(&tms, &tt);
			localtime_s(&tms, &tt);
			std::stringstream stream;
			stream << std::put_time(&tms, format.c_str());
			std::string time = stream.str().append(" ");
			return time;
		}
		int count = 0;
		bool is_Custom = false;
		bool NO_COLOR = false;
		inline static std::string genTimestr(std::string format)
		{
			std::time_t tt = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
			std::tm tms;
			gmtime_s(&tms, &tt);
			localtime_s(&tms, &tt);
			std::stringstream stream;
			stream << std::put_time(&tms, format.c_str());
			std::string time = stream.str();
			return time;
		}
		inline static std::string GetLogPathHelper()
		{
			std::string ret = cgZero::Foundation::Tool::function::_GetEnvironmentVariableA("APPDATA", MAX_PATH);
			std::string path = ret + "\\CloudGame_Fix_Zero\\logs\\";
			return std::format("{}", path);
		}
		inline static std::string GetFileNameHelper()
		{
			std::string filename = genTimestr("[%Y %m %d]") + "ClientZero.log";
			return filename;
		}
		inline void WriteMessage(logLevel reportLevel, std::string txt)
		{
			using namespace cgZero::Foundation::Tool::CONSOLE;
			using namespace cgZero::Foundation::Tool::CONSOLE::Property;
			switch (reportLevel)
			{
			case cgZero::logLevel::Trace:
				SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_BLUE | CONSOLE_COLOR_GREEN);
				break;
			case cgZero::logLevel::Info:
				break;
			case cgZero::logLevel::Debug:
				SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_GREEN);
				break;
			case cgZero::logLevel::WARN:
				SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_YELLOW);
				break;
			case cgZero::logLevel::Error:
				SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_LIGHTRED);
				break;
			case cgZero::logLevel::FATAL:
				SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_RED);
				break;
			case cgZero::logLevel::Reserved:
				throw Interface::Exceptions::reservedArgs("保留值是为将来使用的");
			}
			if (this->count < 2) {
				std::clog << txt << "\n";
				this->count++;
			}
			else {
				std::clog << txt << std::endl;
				this->count = 0;
			}
			SetConsoleTextAttribute(this->UserOption.Render, CONSOLE_OUTPUT_HANDLE, CONSOLE_COLOR_WHITE);
		}
		struct logLevels
		{
		public:
			logLevels()
			{
				this->string_LEVEL =
				{
					{cgZero::logLevel::Reserved,		"\0"},
					{cgZero::logLevel::Trace,			"[TRACE]"},
					{cgZero::logLevel::Info,			"[INFO]"},
					{cgZero::logLevel::FATAL,			"[FATAL]"},
					{cgZero::logLevel::Debug,			"[Debug]"},
					{cgZero::logLevel::Error,			"[ERROR]"},
					{cgZero::logLevel::WARN,			"[WARN]"},
				};
			}
			inline std::string get_Str(logLevel level) {return string_LEVEL[level];}
			virtual ~logLevels() {this->string_LEVEL.clear();}
		private: std::map<logLevel, std::string> string_LEVEL;
		};
		std::ofstream logSystemObject;
	};

	class logger : virtual private zeroLog
	{
	public:
		logger(bool&& _Init_, std::string&& path = std::string(), LOGGLOBALOPT option = defaultOption) : zeroLog(_Init_, path, false, option) {}
		virtual ~logger()															= default;
		BOOL init()																	{ return this->Init();}
		virtual inline logger& setLocation(_In_ std::string path) noexcept override { this->filepath = path; return *this; }
		virtual inline logger& setFileName(_In_ std::string name) noexcept override { this->savename = name; return *this; }
		static logger* Instance(){
			static logger loggerObjectCgFix(true);
			return &loggerObjectCgFix;
		}
		logger& TRACE(_In_ LPCSTR txt, const bool show = true, const std::source_location location = std::source_location::current()){
			this->write(logLevel::Trace, txt, show, location);
			return *this;
		}
		logger& INFO(_In_ LPCSTR txt,const bool show = true,const std::source_location location = std::source_location::current()){
			this->write(logLevel::Info, txt, show,location);
			return *this;
		}
		logger& Debug(_In_ LPCSTR txt,const bool show = true,const std::source_location location = std::source_location::current()){
			this->write(logLevel::Debug, txt, show, location);
			return *this;
		}
		logger& WARN(_In_ LPCSTR txt,const bool show = true,const std::source_location location = std::source_location::current()){
			this->write(logLevel::WARN, txt, show, location);
			return *this;
		}
		logger& Error(_In_ LPCSTR txt,const bool show = true,const std::source_location location = std::source_location::current()){
			this->write(logLevel::Error, txt, show, location);
			return *this;
		}
		logger& FATAL(_In_ LPCSTR txt,const bool show = true,const std::source_location location = std::source_location::current()){
			this->write(logLevel::FATAL, txt, show, location);
			return *this;
		}
		virtual logger& closeSystem() override{
			if (this->IsInit()){
				DEBUG_MESSAGE("开始关闭对象实例");
				this->logSystemObject.close();
				DEBUG_MESSAGE("正在重置初始化状态");
				this->isinit = false;
			}
			return *this;
		}
		
		virtual inline logger& operator()(logLevel level) override
		{
			this->ThreadLock.lock();
			if (level == logLevel::Reserved)
			{
				this->ThreadLock.unlock();
				throw Interface::Exceptions::reservedArgs("保留值不可用");
			}
			this->tempLevel = level;
			this->ThreadLock.unlock();
			return *this;
		}
		virtual inline logger& operator<<(LPCSTR txt)
		{
			this->ThreadLock.lock();
			if (!this->IsInit())
			{
				DEBUG_MESSAGE("需要初始化");
				this->ThreadLock.unlock();
				return *this;
			}
			std::stringstream stream;
			logLevels level{};
			if (this->tempLevel == logLevel::Reserved)
			{
				this->ThreadLock.unlock();
				throw Interface::Exceptions::reservedArgs("保留值不可用");
			}
			stream << level.get_Str(this->tempLevel) << (this->UserOption.ShowUser ? " " : "") << (this->UserOption.ShowUser ? cgZero::Foundation::Tool::function::GetUserA() : "") << (" " + (this->UserOption.ShowTime ? this->getTime(this->UserOption.LogFormatTime) : std::string()).append(": ").append(txt));
			this->logbuffer = stream.str();
			if (this->UserOption.OutPut) {
				this->WriteMessage(this->tempLevel, this->logbuffer);
			}
			if (this->UserOption.Save) {
				this->logSystemObject << this->logbuffer << std::endl;
			}
			if (this->status){
				this->stacks.push(this->logbuffer);
			}
			else{
				this->buffer.push_back(this->logbuffer);
			}
			this->ThreadLock.unlock();
			return *this;
		}
	private:
		logger() = delete;
		void operator=(zeroLog other) = delete;
		logger(logger& other) = delete;
		zeroLog& operator=(const logger& other) = delete;
	};

	#pragma endregion

	namespace ToastPlatform
	{
		namespace Enums
		{
			enum class ToastDismissalReason : INT
			{
				UserCanceled = ABI::Windows::UI::Notifications::ToastDismissalReason::ToastDismissalReason_UserCanceled,
				ApplicationHidden = ABI::Windows::UI::Notifications::ToastDismissalReason::ToastDismissalReason_ApplicationHidden,
				TimedOut = ABI::Windows::UI::Notifications::ToastDismissalReason::ToastDismissalReason_TimedOut
			};
			enum Scenario { Default, Alarm, IncomingCall, Reminder };
			enum Duration { System, Short, Long };
			enum class AudioOption { Default, Silent, Loop };
			enum TextField { FirstLine, SecondLine, ThirdLine };
			enum ToastTemplateType
			{
				ImageAndText01 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastImageAndText01,
				ImageAndText02 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastImageAndText02,
				ImageAndText03 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastImageAndText03,
				ImageAndText04 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastImageAndText04,
				Text01 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastText01,
				Text02 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastText02,
				Text03 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastText03,
				Text04 = ABI::Windows::UI::Notifications::ToastTemplateType::ToastTemplateType_ToastText04
			};

			enum class AudioSystemFile : INT
			{
				DefaultSound, IM,
				Mail, Reminder,
				SMS, Alarm,
				Alarm2, Alarm3,
				Alarm4, Alarm5,
				Alarm6, Alarm7,
				Alarm8, Alarm9,
				Alarm10, Call,
				Call1, Call2,
				Call3, Call4,
				Call5, Call6,
				Call7, Call8,
				Call9, Call10,
			};
			enum class CropHint { Square, Circle };

			enum class ToastError
			{
				NoError,
				NotInitialized,
				SystemNotSupported,
				ShellLinkNotCreated,
				InvalidAppUserModelID,
				InvalidParameters,
				InvalidHandler,
				NotDisplayed,
				UnknownError
			};

			enum ShortcutResult
			{
				SHORTCUT_UNCHANGED = 0,
				SHORTCUT_WAS_CHANGED = 1,
				SHORTCUT_WAS_CREATED = 2,
				SHORTCUT_MISSING_PARAMETERS = -1,
				SHORTCUT_INCOMPATIBLE_OS = -2,
				SHORTCUT_COM_INIT_FAILURE = -3,
				SHORTCUT_CREATE_FAILED = -4
			};

			enum class ShortcutPolicy
			{
				SHORTCUT_POLICY_IGNORE,
				SHORTCUT_POLICY_REQUIRE_NO_CREATE,
				SHORTCUT_POLICY_REQUIRE_CREATE,
			};
		}

		namespace API
		{
			namespace Libray
			{
				static const std::map<Enums::AudioSystemFile, std::wstring> AudioFiles =
				{
					{Enums::AudioSystemFile::DefaultSound, L"ms-winsoundevent:Notification.Default"        },
					{Enums::AudioSystemFile::IM,           L"ms-winsoundevent:Notification.IM"             },
					{Enums::AudioSystemFile::Mail,         L"ms-winsoundevent:Notification.Mail"           },
					{Enums::AudioSystemFile::Reminder,     L"ms-winsoundevent:Notification.Reminder"       },
					{Enums::AudioSystemFile::SMS,          L"ms-winsoundevent:Notification.SMS"            },
					{Enums::AudioSystemFile::Alarm,        L"ms-winsoundevent:Notification.Looping.Alarm"  },
					{Enums::AudioSystemFile::Alarm2,       L"ms-winsoundevent:Notification.Looping.Alarm2" },
					{Enums::AudioSystemFile::Alarm3,       L"ms-winsoundevent:Notification.Looping.Alarm3" },
					{Enums::AudioSystemFile::Alarm4,       L"ms-winsoundevent:Notification.Looping.Alarm4" },
					{Enums::AudioSystemFile::Alarm5,       L"ms-winsoundevent:Notification.Looping.Alarm5" },
					{Enums::AudioSystemFile::Alarm6,       L"ms-winsoundevent:Notification.Looping.Alarm6" },
					{Enums::AudioSystemFile::Alarm7,       L"ms-winsoundevent:Notification.Looping.Alarm7" },
					{Enums::AudioSystemFile::Alarm8,       L"ms-winsoundevent:Notification.Looping.Alarm8" },
					{Enums::AudioSystemFile::Alarm9,       L"ms-winsoundevent:Notification.Looping.Alarm9" },
					{Enums::AudioSystemFile::Alarm10,      L"ms-winsoundevent:Notification.Looping.Alarm10"},
					{Enums::AudioSystemFile::Call,         L"ms-winsoundevent:Notification.Looping.Call"   },
					{Enums::AudioSystemFile::Call1,        L"ms-winsoundevent:Notification.Looping.Call1"  },
					{Enums::AudioSystemFile::Call2,        L"ms-winsoundevent:Notification.Looping.Call2"  },
					{Enums::AudioSystemFile::Call3,        L"ms-winsoundevent:Notification.Looping.Call3"  },
					{Enums::AudioSystemFile::Call4,        L"ms-winsoundevent:Notification.Looping.Call4"  },
					{Enums::AudioSystemFile::Call5,        L"ms-winsoundevent:Notification.Looping.Call5"  },
					{Enums::AudioSystemFile::Call6,        L"ms-winsoundevent:Notification.Looping.Call6"  },
					{Enums::AudioSystemFile::Call7,        L"ms-winsoundevent:Notification.Looping.Call7"  },
					{Enums::AudioSystemFile::Call8,        L"ms-winsoundevent:Notification.Looping.Call8"  },
					{Enums::AudioSystemFile::Call9,        L"ms-winsoundevent:Notification.Looping.Call9"  },
					{Enums::AudioSystemFile::Call10,       L"ms-winsoundevent:Notification.Looping.Call10" },
				};

				static const std::map<Enums::ToastError, std::wstring> ToastErrors = {
					{Enums::ToastError::NoError,               L"No error. The process was executed correctly"												},
					{Enums::ToastError::NotInitialized,        L"The library has not been initialized"														},
					{Enums::ToastError::SystemNotSupported,    L"The OS does not support ToastNotification"													},
					{Enums::ToastError::ShellLinkNotCreated,   L"The library was not able to create a Shell Link for the app"								},
					{Enums::ToastError::InvalidAppUserModelID, L"The AUMI is not a valid one"																},
					{Enums::ToastError::InvalidParameters,     L"Invalid parameters, please double-check the AUMI or App Name"								},
					{Enums::ToastError::NotDisplayed,          L"The toast was created correctly but ToastNotification was not able to display the toast"	},
					{Enums::ToastError::UnknownError,          L"Unknown error"																				}
				};

				static std::map<Enums::Scenario, std::wstring> Scenario =
				{
					{Enums::Scenario::Default,				L"Default"},
					{Enums::Scenario::Alarm,				L"Alarm"},
					{Enums::Scenario::IncomingCall,			L"IncomingCall"},
					{Enums::Scenario::Reminder,				L"Reminder"}
				};
				namespace Util
				{
					inline static RTL_OSVERSIONINFOW getRealOSVersion()
					{
						return cgZero::Foundation::dynamincLibrayFunc::function::RtlGetVersion();
					}

					inline HRESULT defaultExecutablePath(_In_ WCHAR* path, _In_ DWORD nSize = MAX_PATH)
					{
						DWORD written = ::GetModuleFileNameExW(GetCurrentProcess(), nullptr, path, nSize);
						DEBUG_MESSAGE(std::format(L"默认的可执行文件位置为 : {}", path).c_str());
						return (written > 0) ? S_OK : E_FAIL;
					}

					inline HRESULT defaultShellLinksDirectory(_In_ WCHAR* path, _In_ DWORD nSize = MAX_PATH)
					{
						DWORD written = GetEnvironmentVariableW(L"APPDATA", path, nSize);
						HRESULT hr = written > 0 ? S_OK : E_INVALIDARG;
						if (SUCCEEDED(hr))
						{
							errno_t result = wcscat_s(path, nSize, L"\\Microsoft\\Windows\\Start Menu\\Programs\\");
							hr = (result == 0) ? S_OK : E_INVALIDARG;
							DEBUG_MESSAGE(std::format(L"默认的快捷方式存储路径为 : {}", path).c_str());
						}
						return hr;
					}

					inline HRESULT defaultShellLinkPath(_In_ std::wstring const& appname, _In_ WCHAR* path, _In_ DWORD nSize = MAX_PATH)
					{
						HRESULT hr = defaultShellLinksDirectory(path, nSize);
						if (SUCCEEDED(hr)) {
							const std::wstring appLink(appname + L".lnk");
							errno_t result = wcscat_s(path, nSize, appLink.c_str());
							hr = (result == 0) ? S_OK : E_INVALIDARG;
							DEBUG_MESSAGE(std::format(L"默认的快捷方式文件存储路径为 : {}", path).c_str());
						}
						return hr;
					}

					inline PCWSTR AsString(_In_ ComPtr<IXmlDocument>& xmlDocument)
					{
						HSTRING xml;
						ComPtr<IXmlNodeSerializer> ser;
						HRESULT hr = xmlDocument.As<IXmlNodeSerializer>(&ser);
						hr = ser->GetXml(&xml);
						if (SUCCEEDED(hr))
						{
							return cgZero::Foundation::dynamincLibrayFunc::function::WindowsGetStringRawBuffer(xml, nullptr);
						}
						return nullptr;
					}

					inline PCWSTR AsString(_In_ HSTRING hstring)
					{
						return cgZero::Foundation::dynamincLibrayFunc::function::WindowsGetStringRawBuffer(hstring, nullptr);
					}

					inline HRESULT setNodeStringValue(_In_ std::wstring const& string, _Out_opt_ IXmlNode* node, _Out_ IXmlDocument* xml) {
						ComPtr<IXmlText> textNode;
						HRESULT hr = xml->CreateTextNode(cgZero::Foundation::Warpper::HstringWrapper(string).Get(), &textNode);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> stringNode;
							hr = textNode.As(&stringNode);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlNode> appendedChild;
								hr = node->AppendChild(stringNode.Get(), &appendedChild);
							}
						}
						return hr;
					}

					inline static HRESULT addAttribute(_In_ IXmlDocument* xml, std::wstring const& name, IXmlNamedNodeMap* attributeMap)
					{
						ComPtr<ABI::Windows::Data::Xml::Dom::IXmlAttribute> srcAttribute;
						HRESULT hr = xml->CreateAttribute(cgZero::Foundation::Warpper::HstringWrapper(name).Get(), &srcAttribute);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> node;
							hr = srcAttribute.As(&node);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlNode> pNode;
								hr = attributeMap->SetNamedItem(node.Get(), &pNode);
							}
						}
						return hr;
					}

					inline static HRESULT createElement(_In_ IXmlDocument* xml, _In_ std::wstring const& root_node, _In_ std::wstring const& element_name,
						_In_ std::vector<std::wstring> const& attribute_names)
					{
						ComPtr<IXmlNodeList> rootList;
						HRESULT hr = xml->GetElementsByTagName(cgZero::Foundation::Warpper::HstringWrapper(root_node).Get(), &rootList);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> root;
							hr = rootList->Item(0, &root);
							if (SUCCEEDED(hr))
							{
								ComPtr<ABI::Windows::Data::Xml::Dom::IXmlElement> audioElement;
								hr = xml->CreateElement(cgZero::Foundation::Warpper::HstringWrapper(element_name).Get(), &audioElement);
								if (SUCCEEDED(hr))
								{
									ComPtr<IXmlNode> audioNodeTmp;
									hr = audioElement.As(&audioNodeTmp);
									if (SUCCEEDED(hr))
									{
										ComPtr<IXmlNode> audioNode;
										hr = root->AppendChild(audioNodeTmp.Get(), &audioNode);
										if (SUCCEEDED(hr))
										{
											ComPtr<IXmlNamedNodeMap> attributes;
											hr = audioNode->get_Attributes(&attributes);
											if (SUCCEEDED(hr))
											{
												for (auto const& it : attribute_names)
												{
													hr = addAttribute(xml, it, attributes.Get());
												}
											}
										}
									}
								}
							}
						}
						return hr;
					}
				}
			}

			namespace Event
			{
				__interface ToastPlatformHandler
				{
					virtual void Activated() const = 0;
					virtual void Activated(int actionIndex) const = 0;
					virtual void Dismissed(Enums::ToastDismissalReason state) const = 0;
					virtual void Failed() const = 0;
				};

				template<typename FunctorT>
				inline HRESULT setEventHandler(
					_In_ ABI::Windows::UI::Notifications::IToastNotification* notification,
					_In_ std::shared_ptr<ToastPlatformHandler> eventHandler,
					_In_ INT64 expirationTime,
					_Out_ EventRegistrationToken& activatedToken,
					_Out_ EventRegistrationToken& dismissedToken,
					_Out_ EventRegistrationToken& failedToken,
					_In_ FunctorT&& markAsReadyForDeletionFunc
				)
				{
					auto actived = [eventHandler, markAsReadyForDeletionFunc](IToastNotification* notify, IInspectable* inspectable)
					{
						ComPtr<IToastActivatedEventArgs> activatedEventArgs;
						HRESULT hr = inspectable->QueryInterface(activatedEventArgs.GetAddressOf());
						if (SUCCEEDED(hr))
						{
							HSTRING argumentsHandle;
							hr = activatedEventArgs->get_Arguments(&argumentsHandle);
							if (SUCCEEDED(hr))
							{
								PCWSTR arguments = Libray::Util::AsString(argumentsHandle);
								if (arguments && *arguments)
								{
									eventHandler->Activated(static_cast<int>(wcstol(arguments, nullptr, 10)));
									cgZero::Foundation::dynamincLibrayFunc::function::WindowsDeleteString(argumentsHandle);
									markAsReadyForDeletionFunc();
									return S_OK;
								}
								cgZero::Foundation::dynamincLibrayFunc::function::WindowsDeleteString(argumentsHandle);
							}
						}
						eventHandler->Activated();
						markAsReadyForDeletionFunc();
						return S_OK;
					};

					auto dismissed = [eventHandler, expirationTime, markAsReadyForDeletionFunc](IToastNotification* notify, IToastDismissedEventArgs* e)
					{
						ToastDismissalReason reason;
						if (SUCCEEDED(e->get_Reason(&reason)))
						{
							if (reason == ToastDismissalReason_UserCanceled && expirationTime && cgZero::Foundation::Warpper::InternalDateTime::Now() >= expirationTime)
							{
								reason = ToastDismissalReason_TimedOut;
							}
							eventHandler->Dismissed(static_cast<Enums::ToastDismissalReason>(reason));
						}
						markAsReadyForDeletionFunc();
						return S_OK;
					};

					auto failed = [eventHandler, markAsReadyForDeletionFunc](IToastNotification* notify, IToastFailedEventArgs* e)
					{
						eventHandler->Failed();
						markAsReadyForDeletionFunc();
						return S_OK;
					};

					HRESULT hr = notification->add_Activated(Callback<Implements<RuntimeClassFlags<ClassicCom>, ITypedEventHandler<ToastNotification*, IInspectable*>>>(actived).Get(), &activatedToken);
					if (SUCCEEDED(hr))
					{
						hr = notification->add_Dismissed(Callback<Implements<RuntimeClassFlags<ClassicCom>, ITypedEventHandler<ToastNotification*, ToastDismissedEventArgs*>>>(dismissed).Get(), &dismissedToken);
						if (SUCCEEDED(hr))
						{
							hr = notification->add_Failed(Callback<Implements<RuntimeClassFlags<ClassicCom>, ITypedEventHandler<ToastNotification*, ToastFailedEventArgs*>>>(failed).Get(), &failedToken);
						}
					}
					return hr;
				}
			}

			class ToastTemplate {
			public:
				ToastTemplate(_In_ Enums::ToastTemplateType type = Enums::ToastTemplateType::ImageAndText02) : _type(type)
				{
					constexpr static std::size_t TextFieldsCount[] = { 1, 2, 2, 3, 1, 2, 2, 3 };
					this->_textFields = std::vector<std::wstring>(TextFieldsCount[type]);
				}
				
				~ToastTemplate()
				{
					this->_textFields.clear();
				}
				
				void setTextField(_In_ std::wstring const& txt, _In_ Enums::TextField pos)
				{
					auto const position = static_cast<std::size_t>(pos);
					if (position >= _textFields.size())
					{
						DEBUG_MESSAGE(std::format(L"您选择的Toast模板仅支持： {} 行", this->_textFields.size()).c_str());
						return;
					}
					this->_textFields[position] = txt;
				}
				
				void setImagePath(_In_ std::wstring const& imgPath, _In_ Enums::CropHint cropHint = Enums::CropHint::Square)
				{
					DEBUG_MESSAGE(std::format(L"设置图像路径为 : {}", imgPath));
					this->_imagePath = imgPath;
					this->_cropHint = cropHint;
				}
				
				void setAudioPath(_In_ Enums::AudioSystemFile file)
				{
					auto const iter = Libray::AudioFiles.find(file);
					assert(iter != Libray::AudioFiles.end());
					_audioPath = iter->second;
				}

				void setScenario(_In_ Enums::Scenario scenario)
				{
					switch (scenario)
					{
					case Enums::Scenario::Default:
						this->_scenario = L"Default";
						break;
					case Enums::Scenario::Alarm:
					{
						this->_scenario = L"Alarm";
						break;
					}
					case Enums::Scenario::IncomingCall:
					{
						this->_scenario = L"IncomingCall";
					}   break;
					case Enums::Scenario::Reminder:
					{
						this->_scenario = L"Reminder";
						break;
					}
					}
					return;
				}

				std::wstring const& textField(_In_ Enums::TextField pos) const
				{
					auto const position = static_cast<std::size_t>(pos);
					assert(position < _textFields.size());
					return this->_textFields[position];
				}
				
				std::wstring const& actionLabel(_In_ std::size_t pos) const
				{
					assert(pos < _actions.size());
					return this->_actions[pos];
				}

				void setFirstLine(_In_ std::wstring const& text)										{ this->setTextField(text, Enums::FirstLine);}
				void setSecondLine(_In_ std::wstring const& text)										{ this->setTextField(text, Enums::SecondLine);}
				void setThirdLine(_In_ std::wstring const& text)										{ this->setTextField(text, Enums::ThirdLine);}
				void setAttributionText(_In_ std::wstring const& attributionText)						{ this->_attributionText = attributionText; }
				void setHeroImagePath(_In_ std::wstring const& imgPath, _In_ bool inlineImage = false)	{ this->_heroImagePath = imgPath; this->_inlineHeroImage = inlineImage; }
				void setAudioPath(_In_ std::wstring const& audioPath)									{ this->_audioPath = audioPath;}
				void setAudioOption(_In_ Enums::AudioOption audioOption)								{ this->_audioOption = audioOption;}
				void setDuration(_In_ Enums::Duration duration)											{ this->_duration = duration;}
				void setExpiration(_In_ INT64 millisecondsFromNow)										{ this->_expiration = millisecondsFromNow;}
				void addAction(_In_ std::wstring const& label)											{ this->_actions.push_back(label); }
				std::size_t actionsCount() const														{ return this->_actions.size(); }
				bool isToastGeneric() const																{ return this->hasHeroImage() || this->_cropHint == Enums::CropHint::Circle; }
				bool isInlineHeroImage() const															{ return this->_inlineHeroImage; }
				bool hasImage() const																	{ return this->_type < Enums::ToastTemplateType::Text01; }
				bool hasHeroImage() const																{ return hasImage() && !this->_heroImagePath.empty(); }
				std::vector<std::wstring> const& textFields() const										{ return this->_textFields; }
				std::size_t textFieldsCount() const														{ return this->_textFields.size(); }
				std::wstring const& imagePath() const													{ return this->_imagePath; }
				std::wstring const& heroImagePath() const												{ return this->_heroImagePath; }
				std::wstring const& audioPath() const													{ return this->_audioPath; }
				std::wstring const& attributionText() const												{ return this->_attributionText; }
				INT64 expiration() const																{ return this->_expiration; }
				std::wstring const& scenario() const													{ return this->_scenario; }
				bool isCropHintCircle() const															{ return this->_cropHint == Enums::CropHint::Circle; }
				Enums::ToastTemplateType type() const													{ return this->_type; }
				Enums::AudioOption audioOption() const													{ return this->_audioOption; }
				Enums::Duration duration() const														{ return this->_duration; }
			private:
				std::vector<std::wstring> _textFields{};
				std::vector<std::wstring> _actions{};
				std::wstring _imagePath{};
				std::wstring _heroImagePath{};
				bool _inlineHeroImage{ false };
				std::wstring _audioPath{};
				std::wstring _attributionText{};
				std::wstring _scenario{L"Default"};
				INT64 _expiration{ 0 };
				Enums::AudioOption _audioOption{ Enums::AudioOption::Default };
				Enums::ToastTemplateType _type{ Enums::ToastTemplateType::Text01 };
				Enums::Duration _duration{ Enums::Duration::System };
				Enums::CropHint _cropHint{ Enums::CropHint::Square };
			};

			class ToastNotification {
			public:
				ToastNotification(void) : _isInitialized(false), _hasCoInitialized(false) {}
				virtual ~ToastNotification()
				{
					this->clear();
					if (_hasCoInitialized) {
						CoUninitialize();
					}
				}
				static ToastNotification* instance()
				{
					static ToastNotification INSTANCE;
					return &INSTANCE;
				}
				static bool isSupportingModernFeatures()
				{
					constexpr auto MinimumSupportedVersion = 6;
					return Libray::Util::getRealOSVersion().dwMajorVersion > MinimumSupportedVersion;
				}
				static bool isWin10AnniversaryOrHigher()
				{
					return Libray::Util::getRealOSVersion().dwBuildNumber >= 14393;
				}
				static std::wstring configureAUMI(_In_ std::wstring const& companyName, _In_ std::wstring const& productName, _In_ std::wstring const& subProduct = std::wstring(), _In_ std::wstring const& versionInformation = std::wstring())
				{
					std::wstring aumi = companyName;
					aumi += L"." + productName;
					if (subProduct.length() > 0)
					{
						aumi += L"." + subProduct;
						if (versionInformation.length() > 0)
						{
							aumi += L"." + versionInformation;
						}
					}
					if (aumi.length() > SCHAR_MAX)
					{
						DEBUG_MESSAGE(L"错误：用户模型ID总长度不应该超过127");
					}
					return aumi;
				}

				static std::wstring const& getToastErrorMessage(_In_ Enums::ToastError error)
				{
					auto const iter = Libray::ToastErrors.find(error);
					assert(iter != Libray::ToastErrors.end());
					return iter->second;
				}

				virtual bool initialize(_Out_opt_ Enums::ToastError* error = nullptr)
				{
					_isInitialized = false;
					setError(error, Enums::ToastError::NoError);
					if (_aumi.empty() || _appName.empty())
					{
						setError(error, Enums::ToastError::InvalidParameters);
						DEBUG_MESSAGE(L"错误：你需要给aumi或者appname设置一个名称，而不是直接初始化");
						return false;
					}

					if (_shortcutPolicy != Enums::ShortcutPolicy::SHORTCUT_POLICY_IGNORE)
					{
						if (createShortcut() < 0) {
							setError(error, Enums::ToastError::ShellLinkNotCreated);
							DEBUG_MESSAGE(L"错误： 如果要触发Toast通知：您必须提供了一个Aumi和一个在开始菜单的快捷方式（不应该忽略创建）");
							return false;
						}
					}
					if (FAILED(SetCurrentProcessExplicitAppUserModelID(_aumi.c_str())))
					{
						setError(error, Enums::ToastError::InvalidAppUserModelID);
						DEBUG_MESSAGE(L"错误：无法设置aumi，某些设置可能出现了错误");
						return false;
					}

					_isInitialized = true;
					return _isInitialized;
				}

				virtual bool isInitialized() const										{ return this->_isInitialized; }
				std::wstring const& getAppName() const									{ return this->_appName; };
				std::wstring const& getAppUserModelId() const							{ return this->_aumi; };
				void setAppUserModelId(_In_ std::wstring const& aumi)					{ this->_aumi = aumi; }
				void setAppName(_In_ std::wstring const& AppName)						{ this->_appName = AppName; }
				void setShortcutPolicy(_In_ Enums::ShortcutPolicy policy)				{ this->_shortcutPolicy = policy; }

				virtual bool hideToast(_In_ INT64 id)
				{
					if (!isInitialized())
					{
						DEBUG_MESSAGE("Error when hiding the toast. ToastNotification is not initialized.");
						return false;
					}
					auto iter = _buffer.find(id);
					if (iter == _buffer.end())
					{
						return false;
					}
					auto succeded = false;
					auto notify = notifier(&succeded);
					if (!succeded)
					{
						return false;
					}
					auto& notifyData = iter->second;
					auto result = notify->Hide(notifyData.notification());
					if (FAILED(result))
					{
						DEBUG_MESSAGE(std::format("隐藏吐司失败！. 代码: {}", result).c_str());
						return false;
					}
					notifyData.RemoveTokens();
					_buffer.erase(iter);
					return SUCCEEDED(result);
				}

				virtual INT64 showToast(_In_ ToastTemplate const& toast, _In_ Event::ToastPlatformHandler* eventHandler, Enums::ToastError* error = nullptr)
				{
					using namespace cgZero::Foundation::Warpper;
					using namespace cgZero::Foundation::dynamincLibrayFunc::function;
					std::shared_ptr<Event::ToastPlatformHandler> handler(eventHandler);
					setError(error, Enums::ToastError::NoError);
					INT64 id = -1;
					if (!isInitialized())
					{
						setError(error, Enums::ToastError::NotInitialized);
						DEBUG_MESSAGE(L"Error when launching the toast. ToastNotification is not initialized.");
						return id;
					}
					if (!handler)
					{
						setError(error, Enums::ToastError::InvalidHandler);
						DEBUG_MESSAGE(L"Error when launching the toast. Handler cannot be nullptr.");
						return id;
					}
					ComPtr<IToastNotificationManagerStatics> notificationManager;
					HRESULT hr = Wrap_GetActivationFactory(HstringWrapper(RuntimeClass_Windows_UI_Notifications_ToastNotificationManager).Get(), &notificationManager);
					if (SUCCEEDED(hr))
					{
						ComPtr<IToastNotifier> notifier;
						hr = notificationManager->CreateToastNotifierWithId(HstringWrapper(this->_aumi).Get(), &notifier);
						if (SUCCEEDED(hr))
						{
							ComPtr<IToastNotificationFactory> notificationFactory;
							hr = Wrap_GetActivationFactory(HstringWrapper(RuntimeClass_Windows_UI_Notifications_ToastNotification).Get(), &notificationFactory);
							if (SUCCEEDED(hr))
							{
								/* 此处将会开始构建Toast xml文件 */
								ComPtr<IXmlDocument> xmlDocument;
								hr = notificationManager->GetTemplateContent(ToastTemplateType(toast.type()), &xmlDocument);
								if (SUCCEEDED(hr) && toast.isToastGeneric())
								{
									hr = this->setBindToastGenericHelper(xmlDocument.Get());
								}
								if (SUCCEEDED(hr))
								{
									for (UINT32 i = 0, fieldsCount = static_cast<UINT32>(toast.textFieldsCount()); i < fieldsCount && SUCCEEDED(hr); i++)
									{
										hr = this->setTextFieldHelper(xmlDocument.Get(), toast.textField(Enums::TextField(i)), i);
									}
									// Modern feature are supported Windows > Windows 10
									if (SUCCEEDED(hr) && isSupportingModernFeatures())
									{
										// Note that we do this *after* using toast.textFieldsCount() to
										// iterate/fill the template's text fields, since we're adding yet another text field.
										if (SUCCEEDED(hr) && !toast.attributionText().empty())
										{
											hr = setAttributionTextFieldHelper(xmlDocument.Get(), toast.attributionText());
										}
										std::array<WCHAR, 12> buf{};
										for (std::size_t i = 0, actionsCount = toast.actionsCount(); i < actionsCount && SUCCEEDED(hr); i++)
										{
											_snwprintf_s(buf.data(), buf.size(), _TRUNCATE, L"%zd", i);
											hr = addActionHelper(xmlDocument.Get(), toast.actionLabel(i), buf.data());
										}
										if (SUCCEEDED(hr))
										{
											hr = (toast.audioPath().empty() && toast.audioOption() == Enums::AudioOption::Default) ? hr : setAudioFieldHelper(xmlDocument.Get(), toast.audioPath(), toast.audioOption());
										}
										if (SUCCEEDED(hr) && toast.duration() != Enums::Duration::System)
										{
											hr = addDurationHelper(xmlDocument.Get(), (toast.duration() == Enums::Duration::Short) ? L"short" : L"long");
										}
										if (SUCCEEDED(hr))
										{
											hr = addScenarioHelper(xmlDocument.Get(), toast.scenario());
										}
									}
									else
									{
										DEBUG_MESSAGE(L"当前版本不支持该现代特性: -> (Actions/Sounds/Attributes)");
									}
									if (SUCCEEDED(hr))
									{
										bool isWin10AnniversaryOrAbove = ToastNotification::isWin10AnniversaryOrHigher();
										bool isCircleCropHint = isWin10AnniversaryOrAbove ? toast.isCropHintCircle() : false;
										hr = toast.hasImage() ? setImageFieldHelper(xmlDocument.Get(), toast.imagePath(), toast.isToastGeneric(), isCircleCropHint) : hr;
										if (SUCCEEDED(hr) && isWin10AnniversaryOrAbove && toast.hasHeroImage())
										{
											hr = setHeroImageHelper(xmlDocument.Get(), toast.heroImagePath(), toast.isInlineHeroImage());
										}
										if (SUCCEEDED(hr))
										{
											ComPtr<IToastNotification> notification;
											hr = notificationFactory->CreateToastNotification(xmlDocument.Get(), &notification);
											if (SUCCEEDED(hr))
											{
												INT64 expiration = 0, relativeExpiration = toast.expiration();
												if (relativeExpiration > 0)
												{
													InternalDateTime expirationDateTime(relativeExpiration);
													expiration = expirationDateTime;
													hr = notification->put_ExpirationTime(&expirationDateTime);
												}
												EventRegistrationToken activatedToken{}, dismissedToken{}, failedToken{};
												GUID guid;
												HRESULT hrGuid = CoCreateGuid(&guid);
												id = guid.Data1;
												if (SUCCEEDED(hr) && SUCCEEDED(hrGuid))
												{
													hr = Event::setEventHandler(notification.Get(), handler, expiration, activatedToken, dismissedToken,
														failedToken, [this, id]() { markAsReadyForDeletion(id); });
													if (FAILED(hr))
													{
														setError(error, Enums::ToastError::InvalidHandler);
													}
												}
												if (SUCCEEDED(hr))
												{
													if (SUCCEEDED(hr))
													{
														this->_buffer.emplace(id, NotifyData(notification, activatedToken, dismissedToken, failedToken));
														DEBUG_MESSAGE(std::format(L"构建Toast得到的XML内容： {}", Libray::Util::AsString(xmlDocument)).c_str());
														hr = notifier->Show(notification.Get());
														if (FAILED(hr))
														{
															setError(error, Enums::ToastError::NotDisplayed);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					return FAILED(hr) ? -1 : id;
				}

				virtual void clear()
				{
					auto succeded = false;
					auto notify = notifier(&succeded);
					if (!succeded)
					{
						return;
					}
					for (auto& data : _buffer)
					{
						auto& notifyData = data.second;
						notify->Hide(notifyData.notification());
						notifyData.RemoveTokens();
					}
					_buffer.clear();
				}

				virtual Enums::ShortcutResult createShortcut()
				{
					if (_aumi.empty() || _appName.empty())
					{
						DEBUG_MESSAGE(L"错误：用户模型或用户名中，其中有一个为空");
						return Enums::ShortcutResult::SHORTCUT_MISSING_PARAMETERS;
					}
					if (!_hasCoInitialized)
					{
						HRESULT initHr = CoInitializeEx(nullptr, COINIT::COINIT_MULTITHREADED);
						if (initHr != RPC_E_CHANGED_MODE)
						{
							if (FAILED(initHr) && initHr != S_FALSE)
							{
								DEBUG_MESSAGE(L"无法初始化COM库组件!");
								return Enums::ShortcutResult::SHORTCUT_COM_INIT_FAILURE;
							}
							else
							{
								_hasCoInitialized = true;
							}
						}
					}

					bool wasChanged;
					HRESULT hr = validateShellLinkHelper(wasChanged);
					if (SUCCEEDED(hr)) {
						return wasChanged ? Enums::ShortcutResult::SHORTCUT_WAS_CHANGED : Enums::ShortcutResult::SHORTCUT_UNCHANGED;
					}

					hr = createShellLinkHelper();
					return SUCCEEDED(hr) ? Enums::ShortcutResult::SHORTCUT_WAS_CREATED : Enums::ShortcutResult::SHORTCUT_CREATE_FAILED;
				}
			protected:
				interface NotifyData
				{
					explicit NotifyData() = default;
					NotifyData(
						_In_ ComPtr<IToastNotification> notify,
						_In_ EventRegistrationToken activatedToken,
						_In_ EventRegistrationToken dismissedToken,
						_In_ EventRegistrationToken failedToken
					) : _notify(notify), _activatedToken(activatedToken), _dismissedToken(dismissedToken), _failedToken(failedToken) {}
					~NotifyData()								{RemoveTokens();}
					void markAsReadyForDeletion()				{_readyForDeletion = true;}
					bool isReadyForDeletion() const				{return _readyForDeletion;}
					IToastNotification* notification()			{return _notify.Get();}
					void RemoveTokens()
					{
						if (!_readyForDeletion)
						{
							return;
						}
						if (_previouslyTokenRemoved)
						{
							return;
						}
						if (!_notify.Get())
						{
							return;
						}
						_notify->remove_Activated(_activatedToken);
						_notify->remove_Dismissed(_dismissedToken);
						_notify->remove_Failed(_failedToken);
						_previouslyTokenRemoved = true;
					}
				private:
					ComPtr<IToastNotification> _notify = nullptr;
					EventRegistrationToken _activatedToken{};
					EventRegistrationToken _dismissedToken{};
					EventRegistrationToken _failedToken{};
					bool _readyForDeletion = false;
					bool _previouslyTokenRemoved = false;
				};

				bool _isInitialized = false;
				bool _hasCoInitialized = false;
				Enums::ShortcutPolicy _shortcutPolicy = Enums::ShortcutPolicy::SHORTCUT_POLICY_REQUIRE_CREATE;
				std::wstring _appName;
				std::wstring _aumi;
				std::map<INT64, NotifyData> _buffer{};
				void markAsReadyForDeletion(_In_ INT64 id)
				{
					// Flush the buffer by removing all the toasts that are ready for deletion
					for (auto it = _buffer.begin(); it != _buffer.end();)
					{
						if (it->second.isReadyForDeletion())
						{
							it->second.RemoveTokens();
							it = _buffer.erase(it);
						}
						else
						{
							++it;
						}
					}

					// Mark the toast as ready for deletion (if it exists) so that it will be removed from the buffer in the next iteration
					auto const iter = _buffer.find(id);
					if (iter != _buffer.end())
					{
						_buffer[id].markAsReadyForDeletion();
					}
				}
				HRESULT validateShellLinkHelper(_Out_ bool& wasChanged)
				{
					WCHAR path[MAX_PATH] = { L'\0' };
					Libray::Util::defaultShellLinkPath(_appName, path);
					DWORD attr = GetFileAttributesW(path);
					if (attr >= 0xFFFFFFF)
					{
						DEBUG_MESSAGE(L"未找到快捷方式，尝试创建一个!");
						return E_FAIL;
					}
					ComPtr<IShellLinkW> shellLink;
					HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&shellLink));
					if (SUCCEEDED(hr))
					{
						ComPtr<IPersistFile> persistFile;
						hr = shellLink.As(&persistFile);
						if (SUCCEEDED(hr))
						{
							hr = persistFile->Load(path, STGM_READWRITE);
							if (SUCCEEDED(hr))
							{
								ComPtr<IPropertyStore> propertyStore;
								hr = shellLink.As(&propertyStore);
								if (SUCCEEDED(hr))
								{
									PROPVARIANT appIdPropVar;
									hr = propertyStore->GetValue(PKEY_AppUserModel_ID, &appIdPropVar);
									if (SUCCEEDED(hr))
									{
										WCHAR AUMI[MAX_PATH];
										hr = cgZero::Foundation::dynamincLibrayFunc::function::PropVariantToString(appIdPropVar, AUMI, MAX_PATH);
										wasChanged = false;
										if (FAILED(hr) || _aumi != AUMI)
										{
											if (_shortcutPolicy == Enums::ShortcutPolicy::SHORTCUT_POLICY_REQUIRE_CREATE)
											{
												// AUMI Changed for the same app, let's update the current value! =)
												wasChanged = true;
												PropVariantClear(&appIdPropVar);
												hr = InitPropVariantFromString(_aumi.c_str(), &appIdPropVar);
												if (SUCCEEDED(hr))
												{
													hr = propertyStore->SetValue(PKEY_AppUserModel_ID, appIdPropVar);
													if (SUCCEEDED(hr))
													{
														hr = propertyStore->Commit();
														if (SUCCEEDED(hr) && SUCCEEDED(persistFile->IsDirty()))
														{
															hr = persistFile->Save(path, TRUE);
														}
													}
												}
											}
											else {
												// Not allowed to touch the shortcut to fix the AUMI
												hr = E_FAIL;
											}
										}
										PropVariantClear(&appIdPropVar);
									}
								}
							}
						}
					}
					return hr;
				}

				HRESULT createShellLinkHelper()
				{
					using namespace cgZero::Foundation::Warpper;
					if (_shortcutPolicy != Enums::ShortcutPolicy::SHORTCUT_POLICY_REQUIRE_CREATE)
					{
						return E_FAIL;
					}
					WCHAR exePath[MAX_PATH]{ L'\0' };
					WCHAR slPath[MAX_PATH]{ L'\0' };
					Libray::Util::defaultShellLinkPath(_appName, slPath);
					Libray::Util::defaultExecutablePath(exePath);
					ComPtr<IShellLinkW> shellLink;
					HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&shellLink));
					if (SUCCEEDED(hr))
					{
						hr = shellLink->SetPath(exePath);
						if (SUCCEEDED(hr))
						{
							hr = shellLink->SetArguments(L"");
							if (SUCCEEDED(hr))
							{
								hr = shellLink->SetWorkingDirectory(exePath);
								if (SUCCEEDED(hr))
								{
									ComPtr<IPropertyStore> propertyStore;
									hr = shellLink.As(&propertyStore);
									if (SUCCEEDED(hr))
									{
										PROPVARIANT appIdPropVar;
										hr = InitPropVariantFromString(_aumi.c_str(), &appIdPropVar);
										if (SUCCEEDED(hr))
										{
											hr = propertyStore->SetValue(PKEY_AppUserModel_ID, appIdPropVar);
											if (SUCCEEDED(hr))
											{
												hr = propertyStore->Commit();
												if (SUCCEEDED(hr))
												{
													ComPtr<IPersistFile> persistFile;
													hr = shellLink.As(&persistFile);
													if (SUCCEEDED(hr))
													{
														hr = persistFile->Save(slPath, TRUE);
													}
												}
											}
											PropVariantClear(&appIdPropVar);
										}
									}
								}
							}
						}
					}
					return hr;
				}

				HRESULT setImageFieldHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& path,_In_ bool isToastGeneric,bool isCropHintCircle)
				{
					using namespace cgZero::Foundation::Warpper;
					assert(path.size() < MAX_PATH);
					wchar_t imagePath[MAX_PATH] = L"file:///";
					HRESULT hr = StringCchCatW(imagePath, MAX_PATH, path.c_str());
					if (SUCCEEDED(hr))
					{
						ComPtr<IXmlNodeList> nodeList;
						HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"image").Get(), &nodeList);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> node;
							hr = nodeList->Item(0, &node);
							ComPtr<IXmlElement> imageElement;
							HRESULT hrImage = node.As(&imageElement);
							if (SUCCEEDED(hr) && SUCCEEDED(hrImage) && isToastGeneric)
							{
								hr = imageElement->SetAttribute(HstringWrapper(L"placement").Get(), HstringWrapper(L"appLogoOverride").Get());
								if (SUCCEEDED(hr) && isCropHintCircle)
								{
									hr = imageElement->SetAttribute(HstringWrapper(L"hint-crop").Get(), HstringWrapper(L"circle").Get());
								}
							}
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlNamedNodeMap> attributes;
								hr = node->get_Attributes(&attributes);
								if (SUCCEEDED(hr))
								{
									ComPtr<IXmlNode> editedNode;
									hr = attributes->GetNamedItem(HstringWrapper(L"src").Get(), &editedNode);
									if (SUCCEEDED(hr))
									{
										Libray::Util::setNodeStringValue(imagePath, editedNode.Get(), xml);
									}
								}
							}
						}
					}
					return hr;
				}

				HRESULT setHeroImageHelper(_In_ IXmlDocument* xml, _In_ std::wstring const& path, _In_ bool isInlineImage)
				{
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"binding").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 length;
						hr = nodeList->get_Length(&length);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> bindingNode;
							if (length > 0)
							{
								hr = nodeList->Item(0, &bindingNode);
							}
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlElement> imageElement;
								hr = xml->CreateElement(HstringWrapper(L"image").Get(), &imageElement);
								if (SUCCEEDED(hr) && isInlineImage == false)
								{
									hr = imageElement->SetAttribute(HstringWrapper(L"placement").Get(), HstringWrapper(L"hero").Get());
								}
								if (SUCCEEDED(hr))
								{
									hr = imageElement->SetAttribute(HstringWrapper(L"src").Get(), HstringWrapper(path).Get());
								}
								if (SUCCEEDED(hr))
								{
									ComPtr<IXmlNode> actionNode;
									hr = imageElement.As(&actionNode);
									if (SUCCEEDED(hr))
									{
										ComPtr<IXmlNode> appendedChild;
										hr = bindingNode->AppendChild(actionNode.Get(), &appendedChild);
									}
								}
							}
						}
					}
					return hr;
				}
				
				HRESULT setBindToastGenericHelper(_In_ IXmlDocument* xml)
				{
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"binding").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 length;
						hr = nodeList->get_Length(&length);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> toastNode;
							hr = nodeList->Item(0, &toastNode);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlElement> toastElement;
								hr = toastNode.As(&toastElement);
								if (SUCCEEDED(hr))
								{
									hr = toastElement->SetAttribute(HstringWrapper(L"template").Get(), HstringWrapper(L"ToastGeneric").Get());
								}
							}
						}
					}
					return hr;
				}

				HRESULT setAudioFieldHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& path,_In_opt_ Enums::AudioOption option = Enums::AudioOption::Default)
				{
					using namespace cgZero::Foundation::Warpper;
					std::vector<std::wstring> attrs;
					if (!path.empty())
					{
						attrs.push_back(L"src");
					}
					if (option == Enums::AudioOption::Loop)
					{
						attrs.push_back(L"loop");
					}
					if (option == Enums::AudioOption::Silent)
					{
						attrs.push_back(L"silent");
					}
					Libray::Util::createElement(xml, L"toast", L"audio", attrs);
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"audio").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						ComPtr<IXmlNode> node;
						hr = nodeList->Item(0, &node);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNamedNodeMap> attributes;
							hr = node->get_Attributes(&attributes);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlNode> editedNode;
								if (!path.empty())
								{
									if (SUCCEEDED(hr))
									{
										hr = attributes->GetNamedItem(HstringWrapper(L"src").Get(), &editedNode);
										if (SUCCEEDED(hr))
										{
											hr = Libray::Util::setNodeStringValue(path, editedNode.Get(), xml);
										}
									}
								}
								if (SUCCEEDED(hr))
								{
									switch (option)
									{
									case Enums::AudioOption::Loop:
									{
										hr = attributes->GetNamedItem(HstringWrapper(L"loop").Get(), &editedNode);
										if (SUCCEEDED(hr))
										{
											hr = Libray::Util::setNodeStringValue(L"true", editedNode.Get(), xml);
										}
										break;
									}
									case Enums::AudioOption::Silent:
									{
										hr = attributes->GetNamedItem(HstringWrapper(L"silent").Get(), &editedNode);
										if (SUCCEEDED(hr))
										{
											hr = Libray::Util::setNodeStringValue(L"true", editedNode.Get(), xml);
										}
										break;
									}
									default:
									{
										break;
									}
									}
								}
							}
						}
					}
					return hr;
				}
				/*
				以下函数中暂时禁用了C4267，因为size_t转到UINT32导致
				*/
				#pragma warning(push)
				#pragma warning(disable : 4267)
				HRESULT setTextFieldHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& text,_In_ size_t pos)
				{
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(Foundation::Warpper::HstringWrapper(L"text").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						ComPtr<IXmlNode> node;
						hr = nodeList->Item(pos, &node);
						if (SUCCEEDED(hr))
						{
							hr = Libray::Util::setNodeStringValue(text, node.Get(), xml);
						}
					}
					return hr;
				}
				#pragma warning(pop)
				
				HRESULT setAttributionTextFieldHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& text)
				{
					using namespace cgZero::Foundation::Warpper;
					Libray::Util::createElement(xml, L"binding", L"text", { L"placement" });
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"text").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 nodeListLength;
						hr = nodeList->get_Length(&nodeListLength);
						if (SUCCEEDED(hr)) {
							for (UINT32 i = 0; i < nodeListLength; i++)
							{
								ComPtr<IXmlNode> textNode;
								hr = nodeList->Item(i, &textNode);
								if (SUCCEEDED(hr))
								{
									ComPtr<IXmlNamedNodeMap> attributes;
									hr = textNode->get_Attributes(&attributes);
									if (SUCCEEDED(hr))
									{
										ComPtr<IXmlNode> editedNode;
										if (SUCCEEDED(hr))
										{
											hr = attributes->GetNamedItem(HstringWrapper(L"placement").Get(), &editedNode);
											if (FAILED(hr) || !editedNode)
											{
												continue;
											}
											hr = Libray::Util::setNodeStringValue(L"attribution", editedNode.Get(), xml);
											if (SUCCEEDED(hr))
											{
												return setTextFieldHelper(xml, text, i);
											}
										}
									}
								}
							}
						}
					}
					return hr;
				}
				
				HRESULT addActionHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& action,_In_ std::wstring const& arguments)
				{
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"actions").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 length;
						hr = nodeList->get_Length(&length);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> actionsNode;
							if (length > 0)
							{
								hr = nodeList->Item(0, &actionsNode);
							}
							else
							{
								hr = xml->GetElementsByTagName(HstringWrapper(L"toast").Get(), &nodeList);
								if (SUCCEEDED(hr)) {
									hr = nodeList->get_Length(&length);
									if (SUCCEEDED(hr))
									{
										ComPtr<IXmlNode> toastNode;
										hr = nodeList->Item(0, &toastNode);
										if (SUCCEEDED(hr))
										{
											ComPtr<IXmlElement> toastElement;
											hr = toastNode.As(&toastElement);
											if (SUCCEEDED(hr))
											{
												hr = toastElement->SetAttribute(HstringWrapper(L"template").Get(), HstringWrapper(L"ToastGeneric").Get());
											}
											if (SUCCEEDED(hr))
											{
												hr = toastElement->SetAttribute(HstringWrapper(L"duration").Get(), HstringWrapper(L"long").Get());
											}
											if (SUCCEEDED(hr))
											{
												ComPtr<IXmlElement> actionsElement;
												hr = xml->CreateElement(HstringWrapper(L"actions").Get(), &actionsElement);
												if (SUCCEEDED(hr))
												{
													hr = actionsElement.As(&actionsNode);
													if (SUCCEEDED(hr))
													{
														ComPtr<IXmlNode> appendedChild;
														hr = toastNode->AppendChild(actionsNode.Get(), &appendedChild);
													}
												}
											}
										}
									}
								}
							}
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlElement> actionElement;
								hr = xml->CreateElement(HstringWrapper(L"action").Get(), &actionElement);
								if (SUCCEEDED(hr))
								{
									hr = actionElement->SetAttribute(HstringWrapper(L"content").Get(), HstringWrapper(action).Get());
								}
								if (SUCCEEDED(hr))
								{
									hr = actionElement->SetAttribute(HstringWrapper(L"arguments").Get(), HstringWrapper(arguments).Get());
								}
								if (SUCCEEDED(hr))
								{
									ComPtr<IXmlNode> actionNode;
									hr = actionElement.As(&actionNode);
									if (SUCCEEDED(hr))
									{
										ComPtr<IXmlNode> appendedChild;
										hr = actionsNode->AppendChild(actionNode.Get(), &appendedChild);
									}
								}
							}
						}
					}
					return hr;
				}

				HRESULT addDurationHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& duration)
				{
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"toast").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 length;
						hr = nodeList->get_Length(&length);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> toastNode;
							hr = nodeList->Item(0, &toastNode);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlElement> toastElement;
								hr = toastNode.As(&toastElement);
								if (SUCCEEDED(hr))
								{
									hr = toastElement->SetAttribute(HstringWrapper(L"duration").Get(), HstringWrapper(duration).Get());
								}
							}
						}
					}
					return hr;
				}

				HRESULT addScenarioHelper(_In_ IXmlDocument* xml,_In_ std::wstring const& scenario)
				{
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IXmlNodeList> nodeList;
					HRESULT hr = xml->GetElementsByTagName(HstringWrapper(L"toast").Get(), &nodeList);
					if (SUCCEEDED(hr))
					{
						UINT32 length;
						hr = nodeList->get_Length(&length);
						if (SUCCEEDED(hr))
						{
							ComPtr<IXmlNode> toastNode;
							hr = nodeList->Item(0, &toastNode);
							if (SUCCEEDED(hr))
							{
								ComPtr<IXmlElement> toastElement;
								hr = toastNode.As(&toastElement);
								if (SUCCEEDED(hr))
								{
									hr = toastElement->SetAttribute(HstringWrapper(L"scenario").Get(), HstringWrapper(scenario).Get());
								}
							}
						}
					}
					return hr;
				}

				ComPtr<IToastNotifier> notifier(_In_ bool* succeded) const
				{
					using namespace cgZero::Foundation::dynamincLibrayFunc::function;
					using namespace cgZero::Foundation::Warpper;
					ComPtr<IToastNotificationManagerStatics> notificationManager;
					ComPtr<IToastNotifier> notifier;
					HRESULT hr = Wrap_GetActivationFactory(HstringWrapper(RuntimeClass_Windows_UI_Notifications_ToastNotificationManager).Get(), &notificationManager);
					if (SUCCEEDED(hr))
					{
						hr = notificationManager->CreateToastNotifierWithId(HstringWrapper(_aumi).Get(), &notifier);
					}
					*succeded = SUCCEEDED(hr);
					return notifier;
				}

				void setError(_Out_opt_ Enums::ToastError* error,_In_ Enums::ToastError value)
				{
					if (error) {
						*error = value;
					}
				}

			};

			class PreDefineHandler : public API::Event::ToastPlatformHandler
			{
				virtual void Activated() const
				{
					//在此插入需要执行的指令
				}
				virtual void Activated(int actionIndex) const
				{
					//在此插入需要执行的指令
				}
				virtual void Dismissed(Enums::ToastDismissalReason state) const
				{
					//在此插入需要执行的指令
				}
				virtual void Failed() const
				{
					//在此插入需要执行的指令
				}
			};
		}
	}
}
#endif // _HAS_CXX20
#endif // CLOUDGAME_FIX_ZERO_H